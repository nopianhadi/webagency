import React from 'react';
import { Page, Employee } from '../types';
import { ScissorsIcon } from './icons/ScissorsIcon';
import { LogOutIcon } from './icons/LogOutIcon';
import { MenuIcon } from './icons/MenuIcon';
import { TVIcon } from './icons/TVIcon';

interface HeaderProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  currentUser: Employee | null;
  onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ currentPage, setCurrentPage, currentUser, onLogout }) => {
  const navItems: { id: Page; label: string }[] = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'queue', label: 'Antrian' },
    { id: 'finance', label: 'Keuangan' },
    { id: 'barbers', label: 'Barber' },
    { id: 'reports', label: 'Laporan' },
    { id: 'settings', label: 'Pengaturan' },
  ];

  const isAdmin = currentUser?.role === 'Admin' || currentUser?.role === 'Cashier';
  const visibleNavItems = isAdmin ? navItems : navItems.filter(item => item.id === 'dashboard' || item.id === 'queue');


  return (
    <header className="bg-white/80 backdrop-blur-sm sticky top-0 z-10 border-b border-slate-200">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-600 p-2 rounded-lg">
              <ScissorsIcon className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-800 tracking-wider">
              Tuang <span className="text-blue-600">Cukur</span>
            </h1>
          </div>
          <nav className="hidden md:flex items-center space-x-2">
            {visibleNavItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setCurrentPage(item.id)}
                className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors duration-300 ${
                  currentPage === item.id
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-500 hover:bg-gray-100 hover:text-gray-800'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>
          <div className="flex items-center space-x-4">
             {isAdmin && (
                <button onClick={() => setCurrentPage('public-queue')} className="hidden md:flex items-center space-x-2 p-2 rounded-full text-gray-500 hover:bg-gray-100 hover:text-gray-800 transition-colors" title="Public View">
                    <TVIcon className="w-6 h-6" />
                </button>
             )}
            <div className="flex items-center space-x-2">
                <div className="text-right hidden sm:block">
                    <p className="text-sm font-semibold text-gray-800">{currentUser?.name}</p>
                    <p className="text-xs text-gray-500">{currentUser?.role}</p>
                </div>
                 <button onClick={onLogout} className="p-2 rounded-full text-gray-500 hover:bg-red-100 hover:text-red-600 transition-colors" title="Logout">
                  <LogOutIcon className="w-6 h-6" />
                </button>
            </div>
            <button className="md:hidden p-2 rounded-full text-gray-500 hover:bg-gray-100 hover:text-gray-800 transition-colors">
              <MenuIcon className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
