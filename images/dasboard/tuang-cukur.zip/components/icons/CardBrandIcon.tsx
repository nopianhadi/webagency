import React from 'react';

export const CardBrandIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg 
        width="48" 
        height="30" 
        viewBox="0 0 48 30" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
        {...props}
    >
        <circle cx="15" cy="15" r="15" fill="white" fillOpacity="0.7"/>
        <circle cx="33" cy="15" r="15" fill="white" fillOpacity="0.4"/>
    </svg>
);
