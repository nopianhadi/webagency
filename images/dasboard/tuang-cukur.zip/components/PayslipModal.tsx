import React from 'react';
import { Employee, Payroll, Transaction, Account } from '../types';

interface PayslipModalProps {
    payroll: Payroll;
    employee?: Employee; // Employee is optional
    onClose: () => void;
    transactions: Transaction[];
    accounts: Account[];
}

const formatCurrency = (value: number) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(value);

const PayslipModal: React.FC<PayslipModalProps> = ({ payroll, employee, onClose, transactions, accounts }) => {
    const paymentDate = new Date(payroll.paymentDate).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
    
    const paymentAccount = accounts.find(acc => acc.id === payroll.accountId);
    const paidTransactions = transactions.filter(t => payroll.paidTransactionIds.includes(t.id));

    // Safely access employee properties with fallbacks
    const employeeName = employee?.name ?? 'N/A';
    const employeeRole = employee?.role ?? 'N/A';
    const employeeCommission = employee?.commission ?? 0;

    return (
        <div className="fixed inset-0 bg-black/30 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg">
                <div id="payslip-content" className="max-h-[85vh] overflow-y-auto">
                    <div className="p-6 border-b">
                        <h3 className="text-xl font-bold text-gray-800">Slip Gaji</h3>
                        <p className="text-sm text-gray-500">Tanggal Pembayaran: {paymentDate}</p>
                    </div>
                     <div className="p-6">
                        <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                                <p className="text-gray-500">Nama</p>
                                <p className="font-semibold text-gray-800">{employeeName}</p>
                            </div>
                             <div>
                                <p className="text-gray-500">Jabatan</p>
                                <p className="font-semibold text-gray-800">{employeeRole}</p>
                            </div>
                             <div>
                                <p className="text-gray-500">Akun Pembayaran</p>
                                <p className="font-semibold text-gray-800">{paymentAccount?.name || 'N/A'}</p>
                            </div>
                             <div>
                                <p className="text-gray-500">Diproses Oleh</p>
                                <p className="font-semibold text-gray-800">{payroll.processedBy}</p>
                            </div>
                        </div>
                    </div>
                    <div className="p-6 border-t space-y-3">
                        <h4 className="text-md font-bold text-gray-800 mb-2">Rincian Pendapatan</h4>
                        <div className="flex justify-between items-center text-sm">
                            <span className="text-gray-600">Gaji Pokok</span>
                            <span className="font-semibold text-gray-800">{formatCurrency(payroll.baseSalary)}</span>
                        </div>
                         <div className="flex justify-between items-center text-sm">
                            <span className="text-gray-600">Total Komisi</span>
                            <span className="font-semibold text-green-600">{formatCurrency(payroll.totalCommission)}</span>
                        </div>
                         <div className="border-t my-2"></div>
                         <div className="flex justify-between items-center text-sm">
                            <span className="font-bold text-gray-800">Total Pendapatan</span>
                            <span className="font-bold text-gray-800">{formatCurrency(payroll.baseSalary + payroll.totalCommission)}</span>
                        </div>
                    </div>
                    
                    <div className="px-6 pt-2 pb-4 border-t">
                        <h4 className="text-md font-bold text-gray-800 mb-2">Rincian Komisi</h4>
                        <div className="max-h-40 overflow-y-auto pr-2">
                            <table className="w-full text-left text-xs">
                                <thead className="text-gray-500">
                                    <tr>
                                        <th className="py-1 font-medium">Layanan & Pelanggan</th>
                                        <th className="py-1 font-medium text-right">Jumlah Komisi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {paidTransactions.map(t => (
                                        <tr key={t.id} className="border-b border-slate-100">
                                            <td className="py-2">
                                                <p className="font-semibold text-gray-800">{t.category}</p>
                                                <p className="text-gray-500">{t.note.replace(` (oleh ${employeeName})`, '').replace('Pelanggan: ','')}</p>
                                            </td>
                                            <td className="py-2 text-right font-semibold text-green-600">
                                                {formatCurrency(t.amount * (employeeCommission / 100))}
                                            </td>
                                        </tr>
                                    ))}
                                    {paidTransactions.length === 0 && (
                                        <tr><td colSpan={2} className="text-center py-4 text-gray-500">Tidak ada rincian komisi.</td></tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <div className="px-6 pt-4 pb-6 border-t space-y-3">
                         <h4 className="text-md font-bold text-gray-800 mb-2">Potongan</h4>
                         <div className="flex justify-between items-center text-sm text-red-600">
                            <span >Lain-lain</span>
                            <span className="font-semibold">({formatCurrency(payroll.deductions)})</span>
                        </div>
                    </div>
                    
                    {payroll.signatureDataUrl && (
                        <div className="px-6 pt-6 pb-4 border-t">
                            <div className="bg-slate-50 border border-dashed rounded-lg p-4 text-center">
                                <p className="text-xs text-gray-500 mb-2">Telah diterima dan disetujui oleh:</p>
                                <img src={payroll.signatureDataUrl} alt="Tanda Tangan" className="h-20 mx-auto object-contain" />
                                <p className="border-t w-48 mx-auto mt-2 pt-1 text-sm font-semibold text-gray-800">{employeeName}</p>
                                <p className="text-xs text-gray-500">Penerima</p>
                            </div>
                        </div>
                    )}

                    <div className="p-6 bg-slate-50 rounded-b-2xl flex justify-between items-center">
                        <span className="font-bold text-lg text-gray-800">Total Diterima</span>
                        <span className="font-bold text-lg text-blue-600">{formatCurrency(payroll.netPay)}</span>
                    </div>
                </div>
                 <div className="p-4 flex justify-end space-x-2 border-t">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-600 bg-white border border-slate-300 rounded-lg hover:bg-slate-50">Tutup</button>
                    <button type="button" onClick={() => window.print()} className="px-4 py-2 text-sm font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700">Cetak</button>
                </div>
            </div>
             <style>
                {`
                    @media print {
                        body * {
                            visibility: hidden;
                        }
                        #payslip-content, #payslip-content * {
                            visibility: visible;
                        }
                         #payslip-content {
                            position: absolute;
                            left: 0;
                            top: 0;
                            width: 100%;
                            max-height: none;
                        }
                    }
                `}
            </style>
        </div>
    );
};

export default PayslipModal;