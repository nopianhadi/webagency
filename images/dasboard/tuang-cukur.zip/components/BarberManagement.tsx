import React, { useState, useMemo, useRef } from 'react';
import { Employee, Attendance, AttendanceStatus, Transaction, TransactionType, Payroll, Account, QueueItem, QueueStatus } from '../types';
import { FileTextIcon } from './icons/FileTextIcon';
import PayslipModal from './PayslipModal';
import { DollarSignIcon } from './icons/DollarSignIcon';
import StatCard from './StatCard';
import { UsersIcon } from './icons/UsersIcon';
import { TrendingUpIcon } from './icons/TrendingUpIcon';
import { XIcon } from './icons/XIcon';
import SignaturePad, { SignaturePadRef } from './SignaturePad';
import { UserIcon } from './icons/UserIcon';
import { CalendarIcon } from './icons/CalendarIcon';
import { ReportMoneyIcon } from './icons/ReportMoneyIcon';


interface BarberManagementProps {
    employees: Employee[];
    attendance: Attendance[];
    transactions: Transaction[];
    payrolls: Payroll[];
    queue: QueueItem[];
    statuses: string[];
    accounts: Account[];
    currentUser: Employee;
    onUpdateStatus: (employeeId: number, status: string) => void;
    onMarkAttendance: (employeeId: number, status: AttendanceStatus) => void;
    onProcessPayment: (employeeId: number, deductions: number, accountId: number, signatureDataUrl: string) => Payroll | undefined;
}

type FilterPeriod = 'today' | 'week' | 'month';

const formatCurrency = (value: number) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(value);

const PaymentModal: React.FC<{ 
    employee: Employee; 
    unpaidCommission: number;
    unpaidTransactions: Transaction[];
    accounts: Account[];
    onClose: () => void;
    onConfirm: (deductions: number, accountId: number, signatureDataUrl: string) => void;
}> = ({ employee, unpaidCommission, unpaidTransactions, accounts, onClose, onConfirm }) => {
    const [deductions, setDeductions] = useState(0);
    const [accountId, setAccountId] = useState(accounts[0]?.id || 0);
    const signatureRef = useRef<SignaturePadRef>(null);

    const baseSalary = (employee.paymentType === 'Gaji Tetap' || employee.paymentType === 'Gaji & Komisi') ? employee.salary : 0;
    const grossPay = baseSalary + unpaidCommission;
    const netPay = grossPay - deductions;

    const handleSubmit = () => {
        if (!accountId) {
            alert("Silakan pilih akun pembayaran.");
            return;
        }
        const signature = signatureRef.current?.getSignature();
        if (signatureRef.current?.isEmpty()) {
            alert("Penerima harus membubuhkan tanda tangan.");
            return;
        }
        onConfirm(deductions, accountId, signature || '');
    };
    
    return (
        <div className="fixed inset-0 bg-black/30 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg">
                <div className="p-6 border-b">
                    <h3 className="text-xl font-bold text-gray-800">Proses Pembayaran Gaji</h3>
                    <p className="text-sm text-gray-500">Untuk: {employee.name}</p>
                </div>
                <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="text-sm font-medium text-gray-600">Bayar Dari Akun</label>
                             <select 
                                value={accountId}
                                onChange={e => setAccountId(Number(e.target.value))}
                                className="w-full mt-1 p-3 border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500"
                            >
                                {accounts.map(acc => <option key={acc.id} value={acc.id}>{acc.name}</option>)}
                            </select>
                        </div>
                         <div>
                            <label className="text-sm font-medium text-gray-600">Potongan</label>
                            <input 
                                type="number" 
                                value={deductions} 
                                onChange={e => setDeductions(Number(e.target.value))} 
                                placeholder="0" 
                                className="w-full mt-1 p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500" 
                            />
                        </div>
                    </div>
                    
                     <div>
                        <p className="text-sm font-medium text-gray-600 mb-2">Rincian Komisi ({unpaidTransactions.length} transaksi)</p>
                        <div className="max-h-32 overflow-y-auto space-y-2 bg-slate-50 p-3 rounded-lg border">
                            {unpaidTransactions.map(t => (
                                <div key={t.id} className="text-xs flex justify-between items-center">
                                    <span className="text-gray-700 truncate pr-2">{t.note.replace(`(oleh ${employee.name})`, '').replace('Pelanggan: ', '')}</span>
                                    <span className="font-semibold text-green-600 whitespace-nowrap">
                                        + {formatCurrency(t.amount * (employee.commission / 100))}
                                    </span>
                                </div>
                            ))}
                            {unpaidTransactions.length === 0 && <p className="text-xs text-center text-gray-500 py-2">Tidak ada komisi yang belum dibayar.</p>}
                        </div>
                    </div>

                    <div className="border-t pt-4 space-y-2">
                         <div className="flex justify-between items-center text-sm">
                            <span className="text-gray-600">Gaji Pokok</span>
                            <span className="font-semibold text-gray-800">{formatCurrency(baseSalary)}</span>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                            <span className="text-gray-600">Total Komisi</span>
                            <span className="font-semibold text-gray-800">{formatCurrency(unpaidCommission)}</span>
                        </div>
                        <div className="flex justify-between items-center text-sm text-red-600">
                            <span className="text-red-600">Potongan</span>
                            <span className="font-semibold text-red-600">({formatCurrency(deductions)})</span>
                        </div>
                         <div className="border-t pt-2 mt-2 flex justify-between items-center">
                            <span className="font-bold text-lg text-gray-800">Total Bersih</span>
                            <span className="font-bold text-lg text-blue-600">{formatCurrency(netPay)}</span>
                        </div>
                    </div>

                    <div>
                        <div className="flex justify-between items-center mb-1">
                            <label className="text-sm font-medium text-gray-600">Tanda Tangan Penerima</label>
                            <button type="button" onClick={() => signatureRef.current?.clear()} className="px-3 py-1 text-xs font-semibold text-gray-600 bg-slate-200 rounded-lg hover:bg-slate-300">
                                Hapus
                            </button>
                        </div>
                        <SignaturePad ref={signatureRef} />
                    </div>
                </div>
                 <div className="bg-slate-50 p-4 flex justify-end space-x-2 rounded-b-2xl">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-600 bg-white border border-slate-300 rounded-lg hover:bg-slate-50">Batal</button>
                    <button type="button" onClick={handleSubmit} className="px-4 py-2 text-sm font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700">Konfirmasi & Bayar</button>
                </div>
            </div>
        </div>
    );
};

const BarberDetailModal: React.FC<BarberManagementProps & { barber: Employee, onClose: () => void, filterPeriod: FilterPeriod, filteredTransactionsForPeriod: Transaction[] }> = ({
    barber, onClose, employees, attendance, transactions, payrolls, queue, statuses, accounts, currentUser, onUpdateStatus, onMarkAttendance, onProcessPayment, filterPeriod, filteredTransactionsForPeriod
}) => {
    const [activeTab, setActiveTab] = useState('summary');
    const [paymentModalVisible, setPaymentModalVisible] = useState(false);
    const [payslipToView, setPayslipToView] = useState<Payroll | null>(null);
    
    const employeeForPayslip = useMemo(() => {
        if (!payslipToView) return undefined;
        // Always find the employee from the main list to get fresh data
        return employees.find(e => e.id === payslipToView.employeeId);
    }, [payslipToView, employees]);
    
    const today = useMemo(() => new Date().toISOString().split('T')[0], []);

    const unpaidTransactions = useMemo(() => transactions.filter(t => 
        t.type === TransactionType.INCOME && !t.commissionPaid && t.note.includes(`(oleh ${barber.name})`)
    ), [transactions, barber.name]);

    const unpaidCommission = useMemo(() => unpaidTransactions.reduce((sum, t) => sum + (t.amount * (barber.commission / 100)), 0), [unpaidTransactions, barber.commission]);
    
    const filterPeriodLabel = filterPeriod === 'today' ? 'Hari Ini' : filterPeriod === 'week' ? 'Minggu Ini' : 'Bulan Ini';

    const commissionForPeriod = useMemo(() => {
        const revenue = filteredTransactionsForPeriod
            .filter(t => t.type === TransactionType.INCOME && t.note.includes(`(oleh ${barber.name})`))
            .reduce((sum, t) => sum + t.amount, 0);
        return revenue * (barber.commission / 100);
    }, [filteredTransactionsForPeriod, barber]);


    const barbersPayrolls = useMemo(() => payrolls.filter(p => p.employeeId === barber.id).sort((a,b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime()), [payrolls, barber.id]);

    const barberQueueToday = useMemo(() => queue.filter(q => q.barber.id === barber.id && q.date === today), [queue, barber.id, today]);

    const attendanceToday = useMemo(() => attendance.find(att => att.date === today && att.employeeId === barber.id)?.status, [attendance, today, barber.id]);

    const handleConfirmPayment = (deductions: number, accountId: number, signatureDataUrl: string) => {
        const newPayslip = onProcessPayment(barber.id, deductions, accountId, signatureDataUrl);
        setPaymentModalVisible(false);
        if(newPayslip) {
            setPayslipToView(newPayslip);
        }
    };

    const tabs = [
        { id: 'summary', label: 'Ringkasan', icon: <UserIcon className="w-4 h-4 mr-2" /> },
        { id: 'queue', label: 'Antrian Hari Ini', icon: <CalendarIcon className="w-4 h-4 mr-2" /> },
        { id: 'history', label: 'Riwayat Gaji', icon: <ReportMoneyIcon className="w-4 h-4 mr-2" /> },
    ];

    const TabContent = () => {
        switch(activeTab) {
            case 'queue':
                return (
                    <div className="space-y-3">
                        {barberQueueToday.length > 0 ? barberQueueToday.map(item => (
                            <div key={item.id} className="bg-slate-50 p-3 rounded-lg flex justify-between items-center">
                                <div>
                                    <p className="font-semibold text-gray-700">{item.customerName} - <span className="text-sm font-normal text-gray-500">{item.service.name}</span></p>
                                    <p className="text-xs text-gray-500">Antrian: {item.queueNumber}</p>
                                </div>
                                <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                                    item.status === QueueStatus.SERVING ? 'bg-blue-100 text-blue-800' :
                                    item.status === QueueStatus.WAITING ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'
                                }`}>{item.status}</span>
                            </div>
                        )) : <p className="text-center text-gray-500 py-8">Tidak ada antrian untuk hari ini.</p>}
                    </div>
                );
            case 'history':
                return (
                    <div className="space-y-3">
                        {barbersPayrolls.length > 0 ? barbersPayrolls.map(p => (
                             <div key={p.id} className="bg-slate-50 p-3 rounded-lg flex justify-between items-center">
                                <div>
                                    <p className="font-semibold text-gray-700">Pembayaran {new Date(p.paymentDate).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                                    <p className="text-sm text-green-600 font-bold">{formatCurrency(p.netPay)}</p>
                                </div>
                                <button onClick={() => setPayslipToView(p)} className="flex items-center space-x-1 px-3 py-1 text-xs font-semibold text-blue-600 bg-blue-100 rounded-md hover:bg-blue-200">
                                    <FileTextIcon className="w-3 h-3" />
                                    <span>Lihat Slip</span>
                                </button>
                            </div>
                        )) : <p className="text-center text-gray-500 py-8">Belum ada riwayat pembayaran.</p>}
                    </div>
                )
            case 'summary':
            default:
                return (
                    <>
                        <div className="mt-4 space-y-2 text-sm bg-slate-50 p-4 rounded-lg border">
                            <div className="flex justify-between font-semibold">
                                <span className="text-gray-500">Total Belum Dibayar:</span>
                                <span className="text-orange-600 text-lg">{formatCurrency(unpaidCommission)}</span>
                            </div>
                            <div className="flex justify-between font-semibold">
                                <span className="text-gray-500">Estimasi Komisi {filterPeriodLabel}:</span>
                                <span className="text-green-600 text-lg">{formatCurrency(commissionForPeriod)}</span>
                            </div>
                            <div className="flex justify-between pt-2 mt-2 border-t">
                                <span className="text-gray-500">Rate Komisi:</span>
                                <span className="font-semibold text-gray-700">{barber.commission}%</span>
                            </div>
                            {(barber.paymentType === 'Gaji Tetap' || barber.paymentType === 'Gaji & Komisi') && (
                                <div className="flex justify-between">
                                    <span className="text-gray-500">Gaji Pokok:</span>
                                    <span className="font-semibold text-gray-700">{formatCurrency(barber.salary)}</span>
                                </div>
                            )}
                        </div>
                        <div className="mt-4 grid grid-cols-2 gap-4">
                            <div>
                                <label className="text-xs font-medium text-gray-500">Status Saat Ini</label>
                                <select value={barber.status} onChange={(e) => onUpdateStatus(barber.id, e.target.value)} className="w-full mt-1 p-2 border border-slate-300 rounded-lg bg-white text-sm focus:ring-2 focus:ring-blue-500">
                                    {statuses.map(s => <option key={s} value={s}>{s}</option>)}
                                </select>
                            </div>
                             <div>
                                <label className="text-xs font-medium text-gray-500">Absensi Hari Ini</label>
                                <div className="grid grid-cols-2 gap-2 mt-1">
                                    <button onClick={() => onMarkAttendance(barber.id, AttendanceStatus.PRESENT)} className={`w-full text-center px-4 py-1.5 text-sm font-semibold rounded-lg ${attendanceToday === AttendanceStatus.PRESENT ? 'bg-green-600 text-white' : 'bg-green-100 text-green-800 hover:bg-green-200'}`}>Hadir</button>
                                    <button onClick={() => onMarkAttendance(barber.id, AttendanceStatus.ABSENT)} className={`w-full text-center px-4 py-1.5 text-sm font-semibold rounded-lg ${attendanceToday === AttendanceStatus.ABSENT ? 'bg-red-600 text-white' : 'bg-red-100 text-red-800 hover:bg-red-200'}`}>Absen</button>
                                </div>
                            </div>
                        </div>
                        <div className="mt-6">
                            <button onClick={() => setPaymentModalVisible(true)} className="w-full flex items-center justify-center space-x-2 px-4 py-3 text-sm font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors">
                                <DollarSignIcon className="w-4 h-4" />
                                <span>Bayar Gaji</span>
                            </button>
                        </div>
                    </>
                );
        }
    }

    return (
        <div className="fixed inset-0 bg-black/40 z-40 flex items-center justify-center p-4" onClick={onClose}>
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl transform transition-all" onClick={e => e.stopPropagation()}>
                <div className="p-6 border-b flex justify-between items-start">
                    <div className="flex items-center space-x-4">
                        <img src={barber.avatarUrl} alt={barber.name} className="w-16 h-16 rounded-full object-cover" />
                        <div>
                            <p className="text-xl font-bold text-gray-800">{barber.name}</p>
                            <p className="text-sm text-gray-500">{barber.role}</p>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-2 text-gray-400 hover:bg-slate-100 rounded-full"><XIcon className="w-5 h-5"/></button>
                </div>
                
                <div className="border-b border-slate-200">
                    <nav className="flex -mb-px px-6">
                        {tabs.map(tab => (
                             <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex items-center px-1 py-4 border-b-2 text-sm font-medium ${activeTab === tab.id ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'} mr-8`}>
                                {tab.icon}{tab.label}
                            </button>
                        ))}
                    </nav>
                </div>

                <div className="p-6 max-h-[50vh] overflow-y-auto">
                    <TabContent />
                </div>
            </div>
            {paymentModalVisible && <PaymentModal 
                employee={barber} 
                unpaidCommission={unpaidCommission}
                unpaidTransactions={unpaidTransactions}
                accounts={accounts}
                onClose={() => setPaymentModalVisible(false)} 
                onConfirm={handleConfirmPayment} 
            />}
            {payslipToView && <PayslipModal 
                payroll={payslipToView} 
                employee={employees.find(e => e.id === payslipToView.employeeId)}
                onClose={() => setPayslipToView(null)}
                transactions={transactions}
                accounts={accounts}
            />}
        </div>
    );
};

const BarberCard: React.FC<{
    barber: Employee;
    attendanceStatus?: AttendanceStatus;
    unpaidCommission: number;
    onClick: () => void;
}> = ({ barber, attendanceStatus, unpaidCommission, onClick }) => {
    
    return (
        <div onClick={onClick} className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 flex flex-col justify-between cursor-pointer hover:shadow-md hover:border-blue-400 transition-all duration-300">
            <div>
                <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-4">
                        <img src={barber.avatarUrl} alt={barber.name} className="w-16 h-16 rounded-full object-cover" />
                        <div>
                            <p className="text-xl font-bold text-gray-800">{barber.name}</p>
                             <span className={`px-3 py-1 mt-1 inline-block text-xs font-medium rounded-full bg-slate-100 text-slate-800`}>
                                {barber.status}
                            </span>
                        </div>
                    </div>
                     <span className={`px-3 py-1 text-xs font-bold rounded-full ${
                        attendanceStatus === AttendanceStatus.PRESENT ? 'bg-green-100 text-green-800' : 
                        attendanceStatus === AttendanceStatus.ABSENT ? 'bg-red-100 text-red-800' :
                        'bg-gray-100 text-gray-800'
                     }`}>
                        {attendanceStatus || 'Belum Absen'}
                    </span>
                </div>

                <div className="mt-4 space-y-2 text-sm bg-slate-50 p-3 rounded-lg">
                    <div className="flex justify-between font-semibold">
                        <span className="text-gray-500">Belum Dibayar:</span>
                        <span className="text-orange-600">{formatCurrency(unpaidCommission)}</span>
                    </div>
                </div>
            </div>
            <div className="mt-4 text-center text-blue-600 font-semibold text-sm">
                Lihat Detail
            </div>
        </div>
    );
};

const BarberManagement: React.FC<BarberManagementProps> = (props) => {
    const { employees, attendance, transactions } = props;
    const [selectedBarber, setSelectedBarber] = useState<Employee | null>(null);
    const [filterPeriod, setFilterPeriod] = useState<FilterPeriod>('today');

    const barbers = employees.filter(e => e.role === 'Barber');
    
    const filteredTransactionsForPeriod = useMemo(() => {
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

        return transactions.filter(t => {
            const tDate = new Date(t.date);
            tDate.setHours(0,0,0,0); 

            if (filterPeriod === 'today') {
                return tDate.getTime() === today.getTime();
            }
            if (filterPeriod === 'week') {
                const weekStart = new Date(today);
                weekStart.setDate(today.getDate() - today.getDay()); 
                return tDate >= weekStart;
            }
            if (filterPeriod === 'month') {
                return tDate.getFullYear() === today.getFullYear() && tDate.getMonth() === today.getMonth();
            }
            return true;
        });
    }, [transactions, filterPeriod]);

    const { totalRevenue, totalCustomers, totalGrossCommission } = useMemo(() => {
        const periodTransactions = filteredTransactionsForPeriod.filter(t => t.type === TransactionType.INCOME && t.note.includes('(oleh'));
        const totalRevenue = periodTransactions.reduce((sum, t) => sum + t.amount, 0);
        const totalCustomers = periodTransactions.length;
        
        const totalGrossCommission = barbers.reduce((total, barber) => {
            const barberRevenue = filteredTransactionsForPeriod
                .filter(t => t.note.includes(`(oleh ${barber.name})`))
                .reduce((sum, t) => sum + t.amount, 0);
            return total + (barberRevenue * (barber.commission / 100));
        }, 0);

        return { totalRevenue, totalCustomers, totalGrossCommission };
    }, [filteredTransactionsForPeriod, barbers]);
    
    const unpaidCommissionsByBarber = useMemo(() => {
        return employees.reduce((acc, emp) => {
            if (emp.role !== 'Barber') return acc;
            
            const unpaidTotal = transactions
                .filter(t => 
                    t.type === TransactionType.INCOME &&
                    !t.commissionPaid &&
                    t.note.includes(`(oleh ${emp.name})`)
                )
                .reduce((sum, t) => sum + (t.amount * (emp.commission / 100)), 0);
            
            acc[emp.id] = unpaidTotal;
            return acc;
        }, {} as Record<number, number>);
    }, [transactions, employees]);

    const today = useMemo(() => new Date().toISOString().split('T')[0], []);
    const attendanceToday = useMemo(() => {
        return attendance.filter(att => att.date === today).reduce((acc, att) => {
            acc[att.employeeId] = att.status;
            return acc;
        }, {} as Record<number, AttendanceStatus>);
    }, [attendance, today]);

    return (
        <div>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
                <h2 className="text-3xl font-extrabold text-gray-800">Manajemen Barber</h2>
                <div className="flex items-center bg-slate-100 p-1 rounded-lg">
                    {(['today', 'week', 'month'] as FilterPeriod[]).map(period => (
                        <button key={period} onClick={() => setFilterPeriod(period)} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors ${filterPeriod === period ? 'bg-white shadow-sm text-blue-600' : 'text-gray-500 hover:text-gray-800'}`}>
                            {period === 'today' ? 'Hari Ini' : period === 'week' ? 'Minggu Ini' : 'Bulan Ini'}
                        </button>
                    ))}
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                <StatCard title="Total Pendapatan" value={formatCurrency(totalRevenue)} icon={<DollarSignIcon className="w-6 h-6" />} />
                <StatCard title="Total Pelanggan" value={`${totalCustomers} Orang`} icon={<UsersIcon className="w-6 h-6" />} />
                <StatCard title="Total Komisi Kotor" value={formatCurrency(totalGrossCommission)} icon={<TrendingUpIcon className="w-6 h-6" />} />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {barbers.map(barber => (
                    <BarberCard
                        key={barber.id}
                        barber={barber}
                        attendanceStatus={attendanceToday[barber.id]}
                        unpaidCommission={unpaidCommissionsByBarber[barber.id] || 0}
                        onClick={() => setSelectedBarber(barber)}
                    />
                ))}
            </div>
            {selectedBarber && <BarberDetailModal 
                {...props} 
                barber={selectedBarber} 
                onClose={() => setSelectedBarber(null)} 
                filterPeriod={filterPeriod}
                filteredTransactionsForPeriod={filteredTransactionsForPeriod}
            />}
        </div>
    );
};

export default BarberManagement;