import React, { useState, useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, LineChart, Line } from 'recharts';
import StatCard from './StatCard';
import { DollarSignIcon } from './icons/DollarSignIcon';
import { UsersIcon } from './icons/UsersIcon';
import { TrendingUpIcon } from './icons/TrendingUpIcon';
import { Employee, EmployeeStatus, Transaction, QueueItem, Payroll, Account } from '../types';
import PayslipModal from './PayslipModal';
import { FileTextIcon } from './icons/FileTextIcon';
import { CreditCardIcon } from './icons/CreditCardIcon';
import { ListIcon } from './icons/ListIcon';

interface DashboardProps {
  employees: Employee[];
  currentUser: Employee;
  transactions: Transaction[];
  queue: QueueItem[];
  payrolls: Payroll[];
  accounts: Account[];
}

type FilterPeriod = 'today' | 'week' | 'month';

const chartData = [
  { name: 'Sen', Omzet: 400000, Pelanggan: 24 },
  { name: 'Sel', Omzet: 300000, Pelanggan: 13 },
  { name: 'Rab', Omzet: 600000, Pelanggan: 38 },
  { name: 'Kam', Omzet: 278000, Pelanggan: 39 },
  { name: 'Jum', Omzet: 189000, Pelanggan: 48 },
  { name: 'Sab', Omzet: 890000, Pelanggan: 38 },
  { name: 'Min', Omzet: 750000, Pelanggan: 43 },
];

const getStatusColor = (status: string) => {
    switch (status) {
        case EmployeeStatus.AVAILABLE: return 'bg-green-100 text-green-800';
        case EmployeeStatus.SERVING: return 'bg-yellow-100 text-yellow-800';
        case EmployeeStatus.ON_BREAK: return 'bg-blue-100 text-blue-800';
        case EmployeeStatus.DAY_OFF: return 'bg-slate-100 text-slate-800';
        default: return 'bg-gray-100 text-gray-800';
    }
}

const BarberStatus: React.FC<{ barber: Employee }> = ({ barber }) => (
  <div className="flex items-center justify-between p-3 rounded-lg hover:bg-slate-50">
    <div className="flex items-center space-x-3">
      <img src={barber.avatarUrl} alt={barber.name} className="w-10 h-10 rounded-full object-cover" />
      <div>
        <p className="font-semibold text-gray-800">{barber.name}</p>
        <p className="text-xs text-gray-500">{barber.role}</p>
      </div>
    </div>
    <div className={`px-3 py-1 text-xs font-medium rounded-full ${getStatusColor(barber.status)}`}>
      {barber.status}
    </div>
  </div>
);

const Dashboard: React.FC<DashboardProps> = ({ employees, currentUser, transactions, queue, payrolls, accounts }) => {
  const isBarber = currentUser.role === 'Barber';
  const barbers = employees.filter(e => e.role === 'Barber');
  const formatCurrency = (value: number) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(value);
  const today = new Date().toISOString().split('T')[0];

  const [selectedPayslip, setSelectedPayslip] = useState<Payroll | null>(null);
  const [activeTab, setActiveTab] = useState('summary');
  const [financeFilter, setFinanceFilter] = useState<FilterPeriod>('today');

  // Calculate stats for the logged-in barber
  const barberTransactionsToday = transactions.filter(t => t.date === today && t.note.includes(`(oleh ${currentUser.name})`));
  const todayRevenue = barberTransactionsToday.reduce((sum, t) => sum + t.amount, 0);
  const todayCustomers = barberTransactionsToday.length;
  const commissionEarned = todayRevenue * (currentUser.commission / 100);

  const barberPayrolls = payrolls.filter(p => p.employeeId === currentUser.id).sort((a,b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime());
  
  const selectedPayslipEmployee = selectedPayslip ? employees.find(e => e.id === selectedPayslip.employeeId) : undefined;

  const filteredFinanceTransactions = useMemo(() => {
    const now = new Date();
    const todayDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    return transactions.filter(t => {
        if (!t.note.includes(`(oleh ${currentUser.name})`)) return false;

        const tDate = new Date(t.date);
        if (financeFilter === 'today') {
            return tDate.toDateString() === todayDate.toDateString();
        }
        if (financeFilter === 'week') {
            const weekStart = new Date(todayDate);
            weekStart.setDate(todayDate.getDate() - todayDate.getDay());
            return tDate >= weekStart;
        }
        if (financeFilter === 'month') {
            return tDate.getFullYear() === todayDate.getFullYear() && tDate.getMonth() === todayDate.getMonth();
        }
        return true;
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [transactions, financeFilter, currentUser.name]);

  const financeSummary = useMemo(() => {
    const grossRevenue = filteredFinanceTransactions.reduce((sum, t) => sum + t.amount, 0);
    const totalCommission = grossRevenue * (currentUser.commission / 100);
    const totalCustomers = filteredFinanceTransactions.length;
    return { grossRevenue, totalCommission, totalCustomers };
  }, [filteredFinanceTransactions, currentUser.commission]);

  const financeChartData = useMemo(() => {
    const grouped = filteredFinanceTransactions.reduce((acc, t) => {
        const date = t.date;
        if (!acc[date]) {
            acc[date] = { date, Pendapatan: 0, Komisi: 0 };
        }
        acc[date].Pendapatan += t.amount;
        acc[date].Komisi += t.amount * (currentUser.commission / 100);
        return acc;
    }, {} as Record<string, { date: string; Pendapatan: number; Komisi: number }>);

    return Object.values(grouped).sort((a: { date: string }, b: { date: string }) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [filteredFinanceTransactions, currentUser.commission]);


  const AdminDashboard = () => (
      <>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <StatCard title="Pendapatan Hari Ini" value="Rp 1.250.000" icon={<DollarSignIcon className="w-6 h-6" />} />
            <StatCard title="Pengeluaran Hari Ini" value="Rp 350.000" icon={<TrendingUpIcon className="w-6 h-6 rotate-180" />} />
            <StatCard title="Pelanggan Hari Ini" value="45 Orang" icon={<UsersIcon className="w-6 h-6" />} />
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <h3 className="text-xl font-bold text-gray-800 mb-4">Grafik Omzet & Pelanggan</h3>
                <div style={{ width: '100%', height: 300 }}>
                    <ResponsiveContainer>
                    <BarChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                        <XAxis dataKey="name" tick={{ fill: '#6b7280' }} axisLine={{ stroke: '#d1d5db' }} tickLine={false} />
                        <YAxis yAxisId="left" orientation="left" stroke="#6b7280" axisLine={false} tickLine={false} />
                        <YAxis yAxisId="right" orientation="right" stroke="#3b82f6" axisLine={false} tickLine={false} />
                        <Tooltip
                            contentStyle={{
                                backgroundColor: 'rgba(255, 255, 255, 0.8)',
                                borderColor: '#e5e7eb',
                                color: '#1f2937',
                                borderRadius: '0.75rem'
                            }}
                            cursor={{fill: 'rgba(59, 130, 246, 0.1)'}}
                        />
                        <Legend wrapperStyle={{paddingTop: '20px'}}/>
                        <Bar yAxisId="left" dataKey="Pelanggan" fill="#93c5fd" name="Jumlah Pelanggan" radius={[4, 4, 0, 0]} />
                        <Bar yAxisId="right" dataKey="Omzet" fill="#3b82f6" name="Omzet (Rp)" radius={[4, 4, 0, 0]}/>
                    </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <h3 className="text-xl font-bold text-gray-800 mb-4">Status Barber</h3>
                <div className="space-y-2">
                    {barbers.map(barber => (
                    <BarberStatus key={barber.id} barber={barber} />
                    ))}
                </div>
            </div>
        </div>
      </>
  );

  const BarberDashboard = () => (
      <>
        <div className="border-b border-slate-200 mb-6">
            <nav className="flex -mb-px space-x-8">
                <button onClick={() => setActiveTab('summary')} className={`flex items-center px-1 py-4 border-b-2 text-sm font-medium ${activeTab === 'summary' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                    <ListIcon className="w-5 h-5 mr-2" /> Ringkasan
                </button>
                <button onClick={() => setActiveTab('finance')} className={`flex items-center px-1 py-4 border-b-2 text-sm font-medium ${activeTab === 'finance' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                    <CreditCardIcon className="w-5 h-5 mr-2" /> Keuangan
                </button>
            </nav>
        </div>

        {activeTab === 'summary' && (
             <div className="space-y-8">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    <StatCard title="Pendapatan Anda Hari Ini" value={formatCurrency(todayRevenue)} icon={<DollarSignIcon className="w-6 h-6" />} />
                    <StatCard title="Pelanggan Anda Layani" value={`${todayCustomers} Orang`} icon={<UsersIcon className="w-6 h-6" />} />
                    <StatCard title="Estimasi Komisi Hari Ini" value={formatCurrency(commissionEarned)} icon={<TrendingUpIcon className="w-6 h-6" />} />
                </div>
                 <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                        <h3 className="text-xl font-bold text-gray-800 mb-4">Riwayat Pembayaran Gaji</h3>
                        <div className="space-y-3 max-h-80 overflow-y-auto pr-2">
                            {barberPayrolls.length > 0 ? barberPayrolls.map(p => (
                                <div key={p.id} className="bg-slate-50 p-3 rounded-lg flex justify-between items-center">
                                    <div>
                                        <p className="font-semibold text-gray-700">Pembayaran {new Date(p.paymentDate).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                                        <p className="text-sm text-green-600 font-bold">{formatCurrency(p.netPay)}</p>
                                    </div>
                                    <button onClick={() => setSelectedPayslip(p)} className="flex items-center space-x-1 px-3 py-1 text-xs font-semibold text-blue-600 bg-blue-100 rounded-md hover:bg-blue-200">
                                        <FileTextIcon className="w-3 h-3" />
                                        <span>Lihat Slip</span>
                                    </button>
                                </div>
                            )) : (
                                <p className="text-center text-gray-500 py-8">Belum ada riwayat pembayaran.</p>
                            )}
                        </div>
                    </div>
                    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                        <h3 className="text-xl font-bold text-gray-800 mb-4">Status Anda</h3>
                        <div className="space-y-2">
                            <BarberStatus barber={currentUser} />
                        </div>
                    </div>
                </div>
            </div>
        )}

        {activeTab === 'finance' && (
            <div className="space-y-8">
                <div className="flex justify-end">
                     <div className="flex items-center bg-slate-100 p-1 rounded-lg">
                        {(['today', 'week', 'month'] as FilterPeriod[]).map(period => (
                            <button key={period} onClick={() => setFinanceFilter(period)} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors ${financeFilter === period ? 'bg-white shadow-sm text-blue-600' : 'text-gray-500 hover:text-gray-800'}`}>
                                {period === 'today' ? 'Hari Ini' : period === 'week' ? 'Minggu Ini' : 'Bulan Ini'}
                            </button>
                        ))}
                    </div>
                </div>
                 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    <StatCard title="Pendapatan Kotor" value={formatCurrency(financeSummary.grossRevenue)} icon={<DollarSignIcon className="w-6 h-6" />} />
                    <StatCard title="Total Pelanggan" value={`${financeSummary.totalCustomers} Orang`} icon={<UsersIcon className="w-6 h-6" />} />
                    <StatCard title="Total Komisi" value={formatCurrency(financeSummary.totalCommission)} icon={<TrendingUpIcon className="w-6 h-6" />} />
                </div>
                 <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                     <h3 className="text-xl font-bold text-gray-800 mb-4">Tren Pendapatan & Komisi</h3>
                     <div style={{ width: '100%', height: 300 }}>
                        <ResponsiveContainer>
                            <LineChart data={financeChartData}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="date" tickFormatter={(tick) => new Date(tick).toLocaleDateString('id-ID', {day: '2-digit', month: 'short'})} />
                                <YAxis tickFormatter={(tick) => `${(tick/1000)}k`}/>
                                <Tooltip contentStyle={{ borderRadius: '0.75rem' }} formatter={(value: number) => formatCurrency(value)} />
                                <Legend />
                                <Line type="monotone" dataKey="Pendapatan" stroke="#3b82f6" strokeWidth={2} />
                                <Line type="monotone" dataKey="Komisi" stroke="#10b981" strokeWidth={2} />
                            </LineChart>
                        </ResponsiveContainer>
                     </div>
                </div>
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                    <div className="p-4 border-b">
                         <h3 className="text-xl font-bold text-gray-800">Rincian Transaksi</h3>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left text-gray-500">
                            <thead className="text-xs text-gray-700 uppercase bg-slate-50">
                                <tr>
                                    <th scope="col" className="px-6 py-3">Tanggal</th>
                                    <th scope="col" className="px-6 py-3">Pelanggan & Layanan</th>
                                    <th scope="col" className="px-6 py-3 text-right">Pendapatan</th>
                                    <th scope="col" className="px-6 py-3 text-right">Komisi Anda</th>
                                    <th scope="col" className="px-6 py-3 text-center">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredFinanceTransactions.map(t => (
                                <tr key={t.id} className="bg-white border-b">
                                    <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">{new Date(t.date).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}</td>
                                    <td className="px-6 py-4">
                                        <p className="font-semibold text-gray-800">{t.note.replace(` (oleh ${currentUser.name})`, '').replace('Pelanggan: ','')}</p>
                                        <p className="text-gray-500">{t.category}</p>
                                    </td>
                                    <td className="px-6 py-4 text-right font-semibold text-gray-800">{formatCurrency(t.amount)}</td>
                                    <td className="px-6 py-4 text-right font-semibold text-green-600">{formatCurrency(t.amount * (currentUser.commission / 100))}</td>
                                    <td className="px-6 py-4 text-center">
                                         <span className={`px-2 py-1 text-xs font-medium rounded-full ${t.commissionPaid ? 'bg-blue-100 text-blue-800' : 'bg-orange-100 text-orange-800'}`}>
                                            {t.commissionPaid ? 'Dibayar' : 'Belum Dibayar'}
                                        </span>
                                    </td>
                                </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    {filteredFinanceTransactions.length === 0 && (
                        <p className="text-center text-gray-500 py-12">Tidak ada transaksi pada periode ini.</p>
                    )}
                </div>
            </div>
        )}

        {selectedPayslip && <PayslipModal 
            payroll={selectedPayslip} 
            employee={selectedPayslipEmployee} 
            onClose={() => setSelectedPayslip(null)}
            transactions={transactions}
            accounts={accounts} 
        />}
      </>
  );
  
  return (
    <div className="space-y-8">
        {isBarber ? <BarberDashboard /> : <AdminDashboard />}
    </div>
  );
};

export default Dashboard;