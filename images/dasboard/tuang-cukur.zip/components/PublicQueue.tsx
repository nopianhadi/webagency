import React, { useEffect, useState } from 'react';
import { QueueItem, QueueStatus } from '../types';
import { ScissorsIcon } from './icons/ScissorsIcon';

interface PublicQueueProps {
  queue: QueueItem[];
}

const ServingCard: React.FC<{ item: QueueItem }> = ({ item }) => (
    <div className="bg-blue-600 text-white rounded-2xl p-6 shadow-lg shadow-blue-500/20 transform animate-pulse-slow">
        <div className="flex items-center justify-between">
            <span className="text-5xl font-extrabold">{item.queueNumber}</span>
             <img src={item.barber.avatarUrl} alt={item.barber.name} className="w-20 h-20 rounded-full border-4 border-blue-400 object-cover" />
        </div>
        <div className="mt-4">
            <p className="text-2xl font-bold truncate">{item.customerName}</p>
            <p className="text-lg text-blue-200">dilayani oleh <span className="font-semibold">{item.barber.name}</span></p>
        </div>
    </div>
);

const WaitingListItem: React.FC<{ item: QueueItem }> = ({ item }) => (
    <div className="bg-slate-700/50 p-4 rounded-lg flex justify-between items-center">
        <div>
            <p className="text-xl font-bold text-white">{item.queueNumber} - {item.customerName}</p>
            <p className="text-sm text-slate-300">{item.service.name}</p>
        </div>
        <div className="text-right">
             <p className="text-sm text-slate-400">Barber</p>
             <p className="font-semibold text-white">{item.barber.name}</p>
        </div>
    </div>
);


const PublicQueue: React.FC<PublicQueueProps> = ({ queue }) => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const servingList = queue.filter(item => item.status === QueueStatus.SERVING);
  const waitingList = queue.filter(item => item.status === QueueStatus.WAITING);

  return (
    <div className="min-h-screen bg-slate-900 text-white p-6 lg:p-10 font-sans">
        <header className="flex justify-between items-center pb-6 border-b border-slate-700">
            <div className="flex items-center space-x-4">
                <div className="bg-blue-600 p-3 rounded-xl">
                  <ScissorsIcon className="w-8 h-8 text-white" />
                </div>
                <h1 className="text-4xl font-extrabold tracking-wider">
                  Tuang <span className="text-blue-500">Cukur</span>
                </h1>
            </div>
            <div className="text-right">
                <p className="text-3xl font-bold">{currentTime.toLocaleTimeString('en-GB')}</p>
                <p className="text-slate-400">{currentTime.toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
            </div>
        </header>

        <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-10">
            <section>
                <h2 className="text-3xl font-bold text-blue-400 mb-4">SEDANG DILAYANI</h2>
                <div className="space-y-6">
                    {servingList.length > 0 ? (
                        servingList.map(item => <ServingCard key={item.id} item={item} />)
                    ) : (
                        <div className="bg-slate-800 p-10 rounded-xl text-center text-slate-400">
                            <p>Belum ada pelanggan yang dilayani</p>
                        </div>
                    )}
                </div>
            </section>
            
            <section>
                <h2 className="text-3xl font-bold text-slate-300 mb-4">DAFTAR TUNGGU ({waitingList.length})</h2>
                 <div className="space-y-4 bg-slate-800 p-4 rounded-xl max-h-[70vh] overflow-y-auto">
                     {waitingList.length > 0 ? (
                        waitingList.map(item => <WaitingListItem key={item.id} item={item} />)
                    ) : (
                        <div className="p-10 text-center text-slate-400">
                            <p>Antrian kosong</p>
                        </div>
                    )}
                </div>
            </section>
        </div>
    </div>
  );
};

export default PublicQueue;
