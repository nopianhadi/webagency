

import React, { useState } from 'react';
import { TransactionType, Service, Employee, PaymentType } from '../types';
import { SettingsIcon } from './icons/SettingsIcon';
import { XIcon } from './icons/XIcon';
import { UserPlusIcon } from './icons/UserPlusIcon';

interface SettingsProps {
    categories: { income: string[], expense: string[] };
    onAddCategory: (type: TransactionType, category: string) => void;
    onDeleteCategory: (type: TransactionType, category: string) => void;
    statuses: string[];
    onAddStatus: (status: string) => void;
    onDeleteStatus: (status: string) => void;
    services: Service[];
    onAddService: (name: string, price: number) => void;
    onDeleteService: (id: number) => void;
    employees: Employee[];
    onAddEmployee: (employee: Omit<Employee, 'id' | 'status'>) => void;
    onDeleteEmployee: (id: number) => void;
}

const AddUserModal: React.FC<{
    onClose: () => void;
    onSave: (data: Omit<Employee, 'id' | 'status'>) => void;
}> = ({ onClose, onSave }) => {
    const [name, setName] = useState('');
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState<'Barber' | 'Cashier' | 'Admin'>('Barber');
    const [paymentType, setPaymentType] = useState<PaymentType>('Gaji & Komisi');
    const [salary, setSalary] = useState(0);
    const [commission, setCommission] = useState(0);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({
            name,
            username,
            password,
            role,
            paymentType,
            salary,
            commission,
            avatarUrl: `https://i.pravatar.cc/150?img=${Math.floor(Math.random() * 70)}`
        });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black/30 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-md">
                <form onSubmit={handleSubmit}>
                    <div className="p-6 max-h-[80vh] overflow-y-auto">
                        <h3 className="text-xl font-bold text-gray-800">Tambah Pengguna Baru</h3>
                        <div className="mt-4">
                            <label className="text-sm font-medium text-gray-600">Nama Pengguna</label>
                            <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Masukkan nama" className="w-full mt-1 p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
                        </div>
                         <div className="mt-4">
                            <label className="text-sm font-medium text-gray-600">Username</label>
                            <input type="text" value={username} onChange={e => setUsername(e.target.value)} placeholder="Username untuk login" className="w-full mt-1 p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
                        </div>
                         <div className="mt-4">
                            <label className="text-sm font-medium text-gray-600">Sandi</label>
                            <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Sandi untuk login" className="w-full mt-1 p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
                        </div>
                         <div className="mt-4">
                            <label className="text-sm font-medium text-gray-600">Peran</label>
                            <select value={role} onChange={e => setRole(e.target.value as 'Barber' | 'Cashier' | 'Admin')} className="w-full mt-1 p-3 border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                <option value="Barber">Barber</option>
                                <option value="Cashier">Kasir</option>
                                <option value="Admin">Admin</option>
                            </select>
                        </div>
                        <div className="mt-4">
                            <label className="text-sm font-medium text-gray-600">Tipe Pembayaran</label>
                            <select value={paymentType} onChange={e => setPaymentType(e.target.value as PaymentType)} className="w-full mt-1 p-3 border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                <option value="Gaji & Komisi">Gaji & Komisi</option>
                                <option value="Gaji Tetap">Gaji Tetap</option>
                                <option value="Hanya Komisi">Hanya Komisi</option>
                            </select>
                        </div>
                        {(paymentType === 'Gaji & Komisi' || paymentType === 'Gaji Tetap') && (
                            <div className="mt-4">
                                <label className="text-sm font-medium text-gray-600">Gaji Pokok</label>
                                <input type="number" value={salary} onChange={e => setSalary(Number(e.target.value))} placeholder="e.g., 2500000" className="w-full mt-1 p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
                            </div>
                        )}
                        {(paymentType === 'Gaji & Komisi' || paymentType === 'Hanya Komisi') && (
                            <div className="mt-4">
                                <label className="text-sm font-medium text-gray-600">Komisi (%)</label>
                                <input type="number" value={commission} onChange={e => setCommission(Number(e.target.value))} placeholder="e.g., 10" className="w-full mt-1 p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
                            </div>
                        )}
                    </div>
                    <div className="bg-slate-50 p-4 flex justify-end space-x-2 rounded-b-2xl">
                        <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-600 bg-white border border-slate-300 rounded-lg hover:bg-slate-50">Batal</button>
                        <button type="submit" className="px-4 py-2 text-sm font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    );
};


const UserManager: React.FC<{
    employees: Employee[];
    onAddEmployee: (employee: Omit<Employee, 'id' | 'status'>) => void;
    onDeleteEmployee: (id: number) => void;
}> = ({ employees, onAddEmployee, onDeleteEmployee }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    
    return (
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold text-gray-800">Manajemen Pengguna</h3>
                <button onClick={() => setIsModalOpen(true)} className="flex items-center space-x-2 px-3 py-2 text-xs font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors">
                    <UserPlusIcon className="w-4 h-4" />
                    <span>Tambah</span>
                </button>
            </div>
            <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
                {employees.map(emp => (
                    <div key={emp.id} className="flex items-center justify-between bg-slate-50 p-2 rounded-lg">
                        <div className="flex items-center space-x-3">
                            <img src={emp.avatarUrl} alt={emp.name} className="w-8 h-8 rounded-full" />
                            <div>
                                <span className="text-sm font-semibold text-gray-700">{emp.name}</span>
                                <p className="text-xs text-gray-500">@{emp.username} - {emp.role}</p>
                            </div>
                        </div>
                        <button 
                            onClick={() => onDeleteEmployee(emp.id)} 
                            className="p-1 text-gray-400 hover:text-red-500 hover:bg-red-100 rounded-full"
                        >
                            <XIcon className="w-4 h-4" />
                        </button>
                    </div>
                ))}
            </div>
            {isModalOpen && <AddUserModal onClose={() => setIsModalOpen(false)} onSave={onAddEmployee} />}
        </div>
    );
}

const CategoryManager: React.FC<{
    title: string;
    type: TransactionType;
    categories: string[];
    onAdd: (type: TransactionType, category: string) => void;
    onDelete: (type: TransactionType, category: string) => void;
}> = ({ title, type, categories, onAdd, onDelete }) => {
    const [newCategory, setNewCategory] = useState('');

    const handleAdd = () => {
        if(newCategory.trim()){
            onAdd(type, newCategory);
            setNewCategory('');
        }
    };

    return (
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <h3 className="text-lg font-bold text-gray-800 mb-4">{title}</h3>
            <div className="space-y-2 mb-4">
                {categories.map(cat => (
                    <div key={cat} className="flex items-center justify-between bg-slate-50 p-2 rounded-lg">
                        <span className="text-sm text-gray-700">{cat}</span>
                        <button 
                            onClick={() => onDelete(type, cat)} 
                            className="p-1 text-gray-400 hover:text-red-500 hover:bg-red-100 rounded-full"
                        >
                            <XIcon className="w-4 h-4" />
                        </button>
                    </div>
                ))}
                {categories.length === 0 && (
                     <p className="text-sm text-center text-gray-500 py-4">Belum ada kategori.</p>
                )}
            </div>
            <div className="flex items-center space-x-2 pt-4 border-t">
                <input 
                    type="text"
                    value={newCategory}
                    onChange={e => setNewCategory(e.target.value)}
                    placeholder="Nama kategori baru..."
                    className="w-full p-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500"
                />
                <button 
                    onClick={handleAdd}
                    className="px-4 py-2 text-sm font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 shrink-0"
                >
                    Tambah
                </button>
            </div>
        </div>
    );
};

const StatusManager: React.FC<{
    statuses: string[];
    onAdd: (status: string) => void;
    onDelete: (status: string) => void;
}> = ({ statuses, onAdd, onDelete }) => {
    const [newStatus, setNewStatus] = useState('');

    const handleAdd = () => {
        if(newStatus.trim()){
            onAdd(newStatus);
            setNewStatus('');
        }
    };
    
    return (
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <h3 className="text-lg font-bold text-gray-800 mb-4">Manajemen Status Barber</h3>
            <div className="space-y-2 mb-4">
                {statuses.map(status => (
                    <div key={status} className="flex items-center justify-between bg-slate-50 p-2 rounded-lg">
                        <span className="text-sm text-gray-700">{status}</span>
                        <button 
                            onClick={() => onDelete(status)} 
                            className="p-1 text-gray-400 hover:text-red-500 hover:bg-red-100 rounded-full"
                        >
                            <XIcon className="w-4 h-4" />
                        </button>
                    </div>
                ))}
            </div>
            <div className="flex items-center space-x-2 pt-4 border-t">
                <input 
                    type="text"
                    value={newStatus}
                    onChange={e => setNewStatus(e.target.value)}
                    placeholder="Nama status baru..."
                    className="w-full p-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500"
                />
                <button 
                    onClick={handleAdd}
                    className="px-4 py-2 text-sm font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 shrink-0"
                >
                    Tambah
                </button>
            </div>
        </div>
    );
}

const ServiceManager: React.FC<{
    services: Service[];
    onAdd: (name: string, price: number) => void;
    onDelete: (id: number) => void;
}> = ({ services, onAdd, onDelete }) => {
    const [newName, setNewName] = useState('');
    const [newPrice, setNewPrice] = useState('');

    const handleAdd = () => {
        const price = parseFloat(newPrice);
        if (newName.trim() && !isNaN(price) && price > 0) {
            onAdd(newName, price);
            setNewName('');
            setNewPrice('');
        }
    };

    const formatCurrency = (value: number) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(value);

    return (
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <h3 className="text-lg font-bold text-gray-800 mb-4">Manajemen Layanan</h3>
            <div className="space-y-2 mb-4 max-h-60 overflow-y-auto">
                {services.map(service => (
                    <div key={service.id} className="flex items-center justify-between bg-slate-50 p-2 rounded-lg">
                        <div>
                            <span className="text-sm font-semibold text-gray-700">{service.name}</span>
                            <p className="text-xs text-gray-500">{formatCurrency(service.price)}</p>
                        </div>
                        <button 
                            onClick={() => onDelete(service.id)} 
                            className="p-1 text-gray-400 hover:text-red-500 hover:bg-red-100 rounded-full"
                        >
                            <XIcon className="w-4 h-4" />
                        </button>
                    </div>
                ))}
                {services.length === 0 && (
                     <p className="text-sm text-center text-gray-500 py-4">Belum ada layanan.</p>
                )}
            </div>
            <div className="flex flex-col space-y-2 pt-4 border-t">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    <input 
                        type="text"
                        value={newName}
                        onChange={e => setNewName(e.target.value)}
                        placeholder="Nama layanan baru..."
                        className="w-full p-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500"
                    />
                    <input 
                        type="number"
                        value={newPrice}
                        onChange={e => setNewPrice(e.target.value)}
                        placeholder="Harga..."
                        className="w-full p-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500"
                    />
                </div>
                <button 
                    onClick={handleAdd}
                    className="w-full px-4 py-2 text-sm font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 shrink-0"
                >
                    Tambah Layanan
                </button>
            </div>
        </div>
    );
};


const Settings: React.FC<SettingsProps> = ({ categories, onAddCategory, onDeleteCategory, statuses, onAddStatus, onDeleteStatus, services, onAddService, onDeleteService, employees, onAddEmployee, onDeleteEmployee }) => {
    return (
        <div>
            <div className="flex items-center gap-3 mb-6">
                <SettingsIcon className="w-8 h-8 text-blue-600" />
                <h2 className="text-3xl font-extrabold text-gray-800">Pengaturan</h2>
            </div>
            
            <div className="space-y-8">
                <div className="bg-slate-100 p-4 rounded-xl border">
                    <h3 className="text-xl font-bold text-gray-800 mb-4 px-2">Manajemen Kategori Transaksi</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <CategoryManager 
                            title="Kategori Pemasukan"
                            type={TransactionType.INCOME}
                            categories={categories.income}
                            onAdd={onAddCategory}
                            onDelete={onDeleteCategory}
                        />
                        <CategoryManager 
                            title="Kategori Pengeluaran"
                            type={TransactionType.EXPENSE}
                            categories={categories.expense}
                            onAdd={onAddCategory}
                            onDelete={onDeleteCategory}
                        />
                    </div>
                </div>

                <div className="bg-slate-100 p-4 rounded-xl border">
                     <h3 className="text-xl font-bold text-gray-800 mb-4 px-2">Manajemen Toko</h3>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <ServiceManager
                            services={services}
                            onAdd={onAddService}
                            onDelete={onDeleteService}
                        />
                        <StatusManager 
                            statuses={statuses}
                            onAdd={onAddStatus}
                            onDelete={onDeleteStatus}
                        />
                     </div>
                </div>

                 <div className="bg-slate-100 p-4 rounded-xl border">
                     <h3 className="text-xl font-bold text-gray-800 mb-4 px-2">Manajemen Pengguna</h3>
                     <UserManager 
                        employees={employees}
                        onAddEmployee={onAddEmployee}
                        onDeleteEmployee={onDeleteEmployee}
                    />
                </div>
            </div>
        </div>
    );
};

export default Settings;