import React, { useState, useMemo } from 'react';
import { QueueItem, QueueStatus, Employee, EmployeeStatus, Service } from '../types';
import { ClockIcon } from './icons/ClockIcon';
import { CheckCircleIcon } from './icons/CheckCircleIcon';
import { PlusIcon } from './icons/PlusIcon';
import { ChevronDownIcon } from './icons/ChevronDownIcon';

interface QueuePortalProps {
  queue: QueueItem[];
  employees: Employee[];
  services: Service[];
  currentUser: Employee;
  onStartService: (id: number) => void;
  onFinishService: (item: QueueItem) => void;
  onSkipCustomer: (id: number) => void;
  onAddToQueue: (data: { customerName: string; serviceId: number; barberId: number; }) => void;
}

const formatDate = (date: Date) => date.toISOString().split('T')[0];

const AddQueueModal: React.FC<{
    onClose: () => void;
    onSave: (data: any) => void;
    barbers: Employee[];
    services: Service[];
    currentUser: Employee;
}> = ({ onClose, onSave, barbers, services, currentUser }) => {
    const [customerName, setCustomerName] = useState('');
    const [serviceId, setServiceId] = useState<number | string>('');
    const [barberId, setBarberId] = useState<number | string>('');
    const isBarber = currentUser.role === 'Barber';

    const availableBarbers = useMemo(() => {
        if (isBarber) return [currentUser];
        return barbers.filter(b => b.role === 'Barber' && b.status === EmployeeStatus.AVAILABLE);
    }, [barbers, isBarber, currentUser]);
    
    React.useEffect(() => {
        if (services.length > 0 && !serviceId) {
            setServiceId(services[0].id);
        }
        if (availableBarbers.length > 0 && !barberId) {
            setBarberId(availableBarbers[0].id);
        }
    }, [services, availableBarbers, serviceId, barberId]);


    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!customerName || !serviceId || !barberId) {
            alert('Please fill all fields.');
            return;
        }
        onSave({
            customerName,
            serviceId: Number(serviceId),
            barberId: Number(barberId),
        });
        onClose();
    };

    const formatCurrency = (value: number) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(value);

    return (
        <div className="fixed inset-0 bg-black/30 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-md">
                <form onSubmit={handleSubmit}>
                    <div className="p-6">
                        <h3 className="text-xl font-bold text-gray-800">Tambah Antrian Baru</h3>
                        <div className="mt-4">
                            <label className="text-sm font-medium text-gray-600">Nama Pelanggan</label>
                            <input type="text" value={customerName} onChange={e => setCustomerName(e.target.value)} placeholder="Masukkan nama" className="w-full mt-1 p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
                        </div>
                        <div className="mt-4">
                            <label className="text-sm font-medium text-gray-600">Layanan</label>
                            <select value={serviceId} onChange={e => setServiceId(Number(e.target.value))} className="w-full mt-1 p-3 border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                               {services.map(s => <option key={s.id} value={s.id}>{s.name} - {formatCurrency(s.price)}</option>)}
                            </select>
                        </div>
                         <div className="mt-4">
                            <label className="text-sm font-medium text-gray-600">Pilih Barber</label>
                            <select value={barberId} onChange={e => setBarberId(Number(e.target.value))} disabled={isBarber} className={`w-full mt-1 p-3 border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${isBarber ? 'bg-slate-100' : ''}`}>
                               {availableBarbers.length > 0 ? availableBarbers.map(b => <option key={b.id} value={b.id}>{b.name}</option>) : <option disabled>Tidak ada barber tersedia</option>}
                            </select>
                        </div>
                    </div>
                    <div className="bg-slate-50 p-4 flex justify-end space-x-2 rounded-b-2xl">
                        <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-600 bg-white border border-slate-300 rounded-lg hover:bg-slate-50">Batal</button>
                        <button type="submit" className="px-4 py-2 text-sm font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const QueueCard: React.FC<{ item: QueueItem, onStart: (id: number) => void, onFinish: (item: QueueItem) => void, onSkip: (id: number) => void }> = ({ item, onStart, onFinish, onSkip }) => {
  const isWaiting = item.status === QueueStatus.WAITING;
  const isServing = item.status === QueueStatus.SERVING;

  return (
    <div className={`p-5 rounded-2xl transition-all duration-300 shadow-sm ${
      isServing ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30' : 'bg-white text-gray-800 border border-slate-200'
    }`}>
      <div className="flex justify-between items-start">
        <div>
          <p className={`font-bold text-2xl ${isServing ? 'text-white' : 'text-blue-600'}`}>{item.queueNumber}</p>
          <p className={`text-lg font-semibold ${isServing ? 'text-white' : 'text-gray-800'}`}>{item.customerName}</p>
          <p className={`text-sm ${isServing ? 'text-blue-200' : 'text-gray-500'}`}>{item.service.name}</p>
        </div>
        <div className="text-right">
          <p className={`text-sm font-medium ${isServing ? 'text-blue-100' : 'text-gray-500'}`}>oleh</p>
          <div className="flex items-center justify-end space-x-2 mt-1">
            <p className={`font-semibold ${isServing ? 'text-white' : 'text-gray-800'}`}>{item.barber.name}</p>
            <img src={item.barber.avatarUrl} alt={item.barber.name} className={`w-8 h-8 rounded-full object-cover border-2 ${isServing ? 'border-blue-300' : 'border-slate-300'}`} />
          </div>
        </div>
      </div>
      {(isWaiting || isServing) && (
        <div className="mt-4 pt-4 border-t border-gray-700/10 flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
          {isWaiting && (
            <button 
              onClick={() => onStart(item.id)}
              className="w-full bg-green-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-600 transition-colors"
            >
              Mulai Layanan
            </button>
          )}
          {isServing && (
            <button 
              onClick={() => onFinish(item)}
              className="w-full bg-white/20 text-white font-bold py-2 px-4 rounded-lg hover:bg-white/30 transition-colors"
            >
              Selesai
            </button>
          )}
          {isWaiting && (
             <button 
              onClick={() => onSkip(item.id)}
              className="w-full bg-red-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-red-600 transition-colors"
            >
              Skip
            </button>
          )}
        </div>
      )}
    </div>
  );
};

const QueuePortal: React.FC<QueuePortalProps> = ({ queue, employees, services, currentUser, onStartService, onFinishService, onSkipCustomer, onAddToQueue }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const today = useMemo(() => formatDate(new Date()), []);
  const [selectedDate, setSelectedDate] = useState(today);
  const [isHistoryCollapsed, setIsHistoryCollapsed] = useState(true);

  const isBarber = currentUser.role === 'Barber';
  
  const filteredQueue = useMemo(() => {
    let baseQueue = isBarber ? queue.filter(item => item.barber.id === currentUser.id) : queue;
    return baseQueue.filter(item => item.date === selectedDate);
  }, [queue, currentUser, isBarber, selectedDate]);
  
  const waitingList = filteredQueue.filter(item => item.status === QueueStatus.WAITING);
  const servingList = filteredQueue.filter(item => item.status === QueueStatus.SERVING);
  const doneList = filteredQueue.filter(item => item.status === QueueStatus.DONE);

  const isToday = selectedDate === today;

  const handleDateChange = (date: string) => {
    setSelectedDate(date);
    setIsHistoryCollapsed(true); // Collapse history when changing date
  };

  return (
    <div className="space-y-8">
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex flex-wrap items-center justify-between gap-4">
            <h2 className="text-xl font-bold text-gray-800">Filter Antrian</h2>
            <div className="flex items-center gap-2">
                <button onClick={() => handleDateChange(today)} className={`px-4 py-2 text-sm font-semibold rounded-lg ${isToday ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}>Hari Ini</button>
                <button onClick={() => handleDateChange(formatDate(new Date(Date.now() - 86400000)))} className={`px-4 py-2 text-sm font-semibold rounded-lg ${selectedDate === formatDate(new Date(Date.now() - 86400000)) ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}>Kemarin</button>
                <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => handleDateChange(e.target.value)}
                    className="px-4 py-2 text-sm font-semibold bg-slate-100 text-slate-600 border-slate-200 border rounded-lg"
                />
            </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Serving Section */}
            <div className="lg:col-span-1">
                <h2 className="text-2xl font-extrabold text-blue-600 mb-4 tracking-wide">
                SEDANG DILAYANI
                </h2>
                <div className="space-y-4">
                {servingList.length > 0 ? (
                    servingList.map(item => <QueueCard key={item.id} item={item} onStart={onStartService} onFinish={onFinishService} onSkip={onSkipCustomer}/>)
                ) : (
                    <div className="bg-white border border-slate-200 p-8 rounded-xl text-center text-gray-500">
                    <p>Tidak ada pelanggan yang sedang dilayani.</p>
                    </div>
                )}
                </div>
            </div>

            {/* Waiting List Section */}
            <div className="lg:col-span-1">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-2xl font-extrabold text-gray-800 flex items-center gap-3">
                        <ClockIcon className="w-7 h-7" />
                        DAFTAR TUNGGU ({waitingList.length})
                    </h2>
                    {isToday && (
                        <button onClick={() => setIsModalOpen(true)} className="flex items-center space-x-2 px-4 py-2 text-sm font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors shrink-0">
                            <PlusIcon className="w-4 h-4" />
                            <span>Tambah</span>
                        </button>
                    )}
                </div>
                <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
                {waitingList.length > 0 ? (
                    waitingList.map(item => <QueueCard key={item.id} item={item} onStart={onStartService} onFinish={onFinishService} onSkip={onSkipCustomer} />)
                ) : (
                    <div className="bg-white border border-slate-200 p-8 rounded-xl text-center text-gray-500">
                    <p>Antrian kosong.</p>
                    </div>
                )}
                </div>
            </div>
            
            {/* Done List Section */}
            <div className="lg:col-span-1">
                <h2 className="text-2xl font-extrabold text-gray-400 mb-4 flex items-center gap-3">
                    <CheckCircleIcon className="w-7 h-7" />
                    SELESAI ({doneList.length})
                </h2>
                {isToday ? (
                    <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
                        {doneList.map(item => (
                            <div key={item.id} className="bg-slate-100 p-4 rounded-lg">
                                <p className="text-gray-500 line-through">{item.queueNumber} - {item.customerName} ({item.service.name})</p>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="bg-slate-100 rounded-lg">
                        <button 
                            onClick={() => setIsHistoryCollapsed(!isHistoryCollapsed)}
                            className="w-full flex justify-between items-center p-4 font-semibold text-gray-600"
                        >
                            <span>Lihat Riwayat Selesai</span>
                            <ChevronDownIcon className={`w-5 h-5 transition-transform ${isHistoryCollapsed ? '' : 'rotate-180'}`} />
                        </button>
                        {!isHistoryCollapsed && (
                            <div className="p-4 border-t border-slate-200 space-y-3 max-h-[50vh] overflow-y-auto">
                               {doneList.length > 0 ? doneList.map(item => (
                                <div key={item.id} className="bg-white p-3 rounded-md">
                                    <p className="text-gray-500 line-through text-sm">{item.queueNumber} - {item.customerName} ({item.service.name})</p>
                                </div>
                               )) : <p className="text-center text-sm text-gray-500 py-4">Tidak ada riwayat.</p>}
                            </div>
                        )}
                    </div>
                )}
            </div>

            {isModalOpen && <AddQueueModal onClose={() => setIsModalOpen(false)} onSave={onAddToQueue} barbers={employees} services={services} currentUser={currentUser} />}
        </div>
    </div>
  );
};

export default QueuePortal;