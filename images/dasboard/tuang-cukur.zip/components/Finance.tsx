import React, { useState, useMemo, useEffect } from 'react';
import { Transaction, TransactionType, Account } from '../types';
import StatCard from './StatCard';
import { DollarSignIcon } from './icons/DollarSignIcon';
import { PlusCircleIcon } from './icons/PlusCircleIcon';
import { MinusCircleIcon } from './icons/MinusCircleIcon';
import { PlusIcon } from './icons/PlusIcon';
import { DownloadIcon } from './icons/DownloadIcon';
import { FilterIcon } from './icons/FilterIcon';
import { CreditCardIcon } from './icons/CreditCardIcon';
import { WalletIcon } from './icons/WalletIcon';
import { CardBrandIcon } from './icons/CardBrandIcon';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { ListIcon } from './icons/ListIcon';
import { XIcon } from './icons/XIcon';
import { UsersIcon } from './icons/UsersIcon';

interface FinanceProps {
  transactions: Transaction[];
  accounts: Account[];
  onAddTransaction: (transaction: Omit<Transaction, 'id'>) => void;
  onAddAccount: (data: Omit<Account, 'id'> & { initialBalance: number }) => void;
  onDeleteAccount: (accountId: number) => void;
  categories: { income: string[]; expense: string[] };
}

type FilterPeriod = 'today' | 'week' | 'month';

const AddAccountModal: React.FC<{
    onClose: () => void;
    onSave: (data: Omit<Account, 'id'> & { initialBalance: number }) => void;
}> = ({ onClose, onSave }) => {
    const [name, setName] = useState('');
    const [type, setType] = useState<'Bank' | 'Tunai'>('Bank');
    const [initialBalance, setInitialBalance] = useState('');
    const [bankName, setBankName] = useState('');
    const [accountHolder, setAccountHolder] = useState('');
    const [last4Digits, setLast4Digits] = useState('');


    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name.trim()) {
            alert('Nama akun tidak boleh kosong.');
            return;
        }
        
        const data: Omit<Account, 'id'> & { initialBalance: number } = {
            name: name.trim(),
            type,
            initialBalance: Number(initialBalance) || 0,
        };

        if (type === 'Bank') {
            data.bankName = bankName.trim();
            data.accountHolder = accountHolder.trim();
            data.last4Digits = last4Digits.trim();
        }

        onSave(data);
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black/30 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-md">
                <form onSubmit={handleSubmit}>
                    <div className="p-6">
                        <h3 className="text-xl font-bold text-gray-800">Tambah Kartu/Akun Baru</h3>
                        <div className="mt-4">
                            <label className="text-sm font-medium text-gray-600">Nama Akun</label>
                            <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="e.g., Rekening Utama, Kas Toko" className="w-full mt-1 p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
                        </div>
                        <div className="mt-4">
                            <label className="text-sm font-medium text-gray-600">Tipe Akun</label>
                            <select value={type} onChange={e => setType(e.target.value as 'Bank' | 'Tunai')} className="w-full mt-1 p-3 border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                <option value="Bank">Bank</option>
                                <option value="Tunai">Tunai</option>
                            </select>
                        </div>
                        {type === 'Bank' && (
                            <>
                                <div className="mt-4">
                                    <label className="text-sm font-medium text-gray-600">Nama Bank</label>
                                    <input type="text" value={bankName} onChange={e => setBankName(e.target.value)} placeholder="e.g., BCA, Mandiri" className="w-full mt-1 p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
                                </div>
                                 <div className="mt-4">
                                    <label className="text-sm font-medium text-gray-600">Nama Pemegang Rekening</label>
                                    <input type="text" value={accountHolder} onChange={e => setAccountHolder(e.target.value)} placeholder="e.g., Budi Santoso" className="w-full mt-1 p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
                                </div>
                                <div className="mt-4">
                                    <label className="text-sm font-medium text-gray-600">4 Digit Terakhir No. Rekening</label>
                                    <input type="text" value={last4Digits} onChange={e => setLast4Digits(e.target.value)} maxLength={4} placeholder="e.g., 9018" className="w-full mt-1 p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
                                </div>
                            </>
                        )}
                        <div className="mt-4">
                            <label className="text-sm font-medium text-gray-600">Saldo Awal (Opsional)</label>
                            <input type="number" value={initialBalance} onChange={e => setInitialBalance(e.target.value)} placeholder="0" className="w-full mt-1 p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
                        </div>
                    </div>
                    <div className="bg-slate-50 p-4 flex justify-end space-x-2 rounded-b-2xl">
                        <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-600 bg-white border border-slate-300 rounded-lg hover:bg-slate-50">Batal</button>
                        <button type="submit" className="px-4 py-2 text-sm font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    );
};


const AddTransactionModal: React.FC<{ 
    onClose: () => void; 
    onSave: (data: any) => void;
    categories: { income: string[]; expense: string[] };
    accounts: Account[];
}> = ({ onClose, onSave, categories, accounts }) => {
    const [type, setType] = useState<TransactionType>(TransactionType.INCOME);
    const [amount, setAmount] = useState('');
    const [category, setCategory] = useState(categories.income[0] || '');
    const [note, setNote] = useState('');
    const [accountId, setAccountId] = useState<number | string>(accounts[0]?.id || '');

    useEffect(() => {
        setCategory(categories[type][0] || '');
    }, [type, categories]);

    const handleTypeChange = (newType: TransactionType) => {
        setType(newType);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!category) {
            alert('Silakan buat kategori terlebih dahulu di menu Pengaturan.');
            return;
        }
         if (!accountId) {
            alert('Silakan buat akun keuangan terlebih dahulu.');
            return;
        }
        onSave({
            type,
            amount: parseFloat(amount),
            category,
            note,
            accountId: Number(accountId),
            date: new Date().toISOString().split('T')[0],
            createdBy: 'kasir1', // Hardcoded for now
        });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black/30 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-md">
                <form onSubmit={handleSubmit}>
                    <div className="p-6">
                        <h3 className="text-xl font-bold text-gray-800">Tambah Transaksi</h3>
                        <div className="mt-4 grid grid-cols-2 gap-2">
                            <button type="button" onClick={() => handleTypeChange(TransactionType.INCOME)} className={`p-3 rounded-lg font-semibold transition-colors ${type === TransactionType.INCOME ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}>Pemasukan</button>
                            <button type="button" onClick={() => handleTypeChange(TransactionType.EXPENSE)} className={`p-3 rounded-lg font-semibold transition-colors ${type === TransactionType.EXPENSE ? 'bg-red-500 text-white' : 'bg-slate-100 text-slate-600'}`}>Pengeluaran</button>
                        </div>
                        <div className="mt-4">
                            <label className="text-sm font-medium text-gray-600">Jumlah</label>
                            <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="0" className="w-full mt-1 p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
                        </div>
                        <div className="mt-4">
                            <label className="text-sm font-medium text-gray-600">Akun Pembayaran</label>
                            <select value={accountId} onChange={e => setAccountId(Number(e.target.value))} className="w-full mt-1 p-3 border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                {accounts.length > 0 ? accounts.map(acc => <option key={acc.id} value={acc.id}>{acc.name}</option>) : <option disabled>Tidak ada akun</option>}
                            </select>
                        </div>
                        <div className="mt-4">
                             <label className="text-sm font-medium text-gray-600">Kategori</label>
                            <select value={category} onChange={e => setCategory(e.target.value)} className="w-full mt-1 p-3 border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                {categories[type].map(cat => <option key={cat} value={cat}>{cat}</option>)}
                            </select>
                        </div>
                        <div className="mt-4">
                             <label className="text-sm font-medium text-gray-600">Catatan (Opsional)</label>
                            <input type="text" value={note} onChange={e => setNote(e.target.value)} placeholder="e.g., Pomade strong hold" className="w-full mt-1 p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
                        </div>
                    </div>
                    <div className="bg-slate-50 p-4 flex justify-end space-x-2 rounded-b-2xl">
                        <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-semibold text-gray-600 bg-white border border-slate-300 rounded-lg hover:bg-slate-50">Batal</button>
                        <button type="submit" className="px-4 py-2 text-sm font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const BalanceCard: React.FC<{
    account: Account;
    balance: string;
    onDelete: (accountId: number) => void;
}> = ({ account, balance, onDelete }) => {
    const isBank = account.type === 'Bank';
    
    const gradient = isBank 
        ? "bg-gradient-to-br from-blue-500 to-indigo-700" 
        : "bg-gradient-to-br from-amber-400 to-orange-500";

    const decorativeCircles = isBank ? [
        { top: '-2.5rem', right: '-2.5rem', size: 'w-32 h-32', opacity: 'bg-white/10' },
        { top: '2.5rem', right: '-5rem', size: 'w-40 h-40', opacity: 'bg-white/5' },
    ] : [
        { top: '-1rem', right: '3rem', size: 'w-20 h-20', opacity: 'bg-white/20' },
        { top: '3rem', right: '-2rem', size: 'w-24 h-24', opacity: 'bg-white/10' },
    ];

    return (
        <div className={`relative rounded-2xl p-6 text-white overflow-hidden shadow-lg h-56 flex flex-col justify-between ${gradient}`}>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onDelete(account.id);
              }}
              className="absolute top-3 right-3 z-20 p-1.5 bg-black/20 rounded-full hover:bg-black/40 transition-colors"
              aria-label={`Hapus akun ${account.name}`}
            >
              <XIcon className="w-4 h-4 text-white" />
            </button>
            {decorativeCircles.map((circle, index) => (
                <div key={index} className={`absolute ${circle.size} rounded-full ${circle.opacity}`} style={{ top: circle.top, right: circle.right }}></div>
            ))}
            <div className="relative z-10">
                <p className="font-bold text-xl text-white/90 truncate">{isBank ? account.accountHolder : account.name}</p>
                <p className="text-sm text-white/70">{isBank ? account.name : 'Uang Tunai'}</p>
            </div>
            
            <div className="relative z-10 mt-auto">
                {isBank && account.last4Digits && (
                   <p className="font-mono tracking-widest text-lg text-white/90">•••• •••• •••• {account.last4Digits}</p>
                )}
                <div className="flex justify-between items-end mt-2">
                     <p className="text-3xl font-bold tracking-wider">{balance}</p>
                     {isBank ? (
                        <p className="font-bold text-xl tracking-widest text-white/80">{account.bankName?.toUpperCase() || 'BANK'}</p>
                     ) : <CardBrandIcon />}
                </div>
            </div>
        </div>
    );
};


const Finance: React.FC<FinanceProps> = ({ transactions, accounts, onAddTransaction, onAddAccount, onDeleteAccount, categories }) => {
    const [filter, setFilter] = useState<FilterPeriod>('month');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isAddAccountModalOpen, setIsAddAccountModalOpen] = useState(false);
    const [selectedCategory, setSelectedCategory] = useState<string>('all');
    const [chartType, setChartType] = useState<TransactionType>(TransactionType.EXPENSE);
    
    const accountMap = useMemo(() => new Map(accounts.map(acc => [acc.id, acc])), [accounts]);

    const allCategories = useMemo(() => {
        const incomeCats = categories.income;
        const expenseCats = categories.expense;
        return ['all', ...Array.from(new Set([...incomeCats, ...expenseCats]))];
    }, [categories]);

    const filteredTransactions = useMemo(() => {
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        
        return transactions.filter(t => {
            const tDate = new Date(t.date);
            if (filter === 'today') {
                return tDate.toDateString() === today.toDateString();
            }
            if (filter === 'week') {
                const weekStart = new Date(today);
                weekStart.setDate(today.getDate() - today.getDay());
                return tDate >= weekStart;
            }
            if (filter === 'month') {
                return tDate.getFullYear() === today.getFullYear() && tDate.getMonth() === today.getMonth();
            }
            return true;
        }).filter(t => {
            if (selectedCategory === 'all') return true;
            return t.category === selectedCategory;
        }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }, [transactions, filter, selectedCategory]);
    
    const balancesByAccount = useMemo(() => {
        return accounts.reduce((acc, account) => {
            const income = transactions.filter(t => t.accountId === account.id && t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
            const expense = transactions.filter(t => t.accountId === account.id && t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
            acc[account.id] = income - expense;
            return acc;
        }, {} as Record<number, number>);
    }, [transactions, accounts]);

    const summary = useMemo(() => {
        const incomeFromClients = filteredTransactions
          .filter(t => t.type === 'income' && t.category !== 'Saldo Awal')
          .reduce((sum, t) => sum + t.amount, 0);
    
        const barberPayments = filteredTransactions
          .filter(t => t.type === 'expense' && t.category === 'Gaji')
          .reduce((sum, t) => sum + t.amount, 0);
    
        const totalExpenses = filteredTransactions
          .filter(t => t.type === 'expense')
          .reduce((sum, t) => sum + t.amount, 0);
        
        const net = incomeFromClients - totalExpenses;
    
        return { incomeFromClients, barberPayments, totalExpenses, net };
    }, [filteredTransactions]);

    const chartData = useMemo(() => {
        const grouped = filteredTransactions.reduce((acc, t) => {
            const date = t.date;
            if (!acc[date]) {
                acc[date] = { date, income: 0, expense: 0 };
            }
            if (t.type === 'income') {
                acc[date].income += t.amount;
            } else {
                acc[date].expense += t.amount;
            }
            return acc;
        }, {} as Record<string, { date: string; income: number; expense: number }>);
        // FIX: Explicitly typed sort callback parameters to fix 'unknown' type error.
        return Object.values(grouped).sort((a: { date: string }, b: { date: string }) => new Date(a.date).getTime() - new Date(b.date).getTime());
    }, [filteredTransactions]);

    const pieChartData = useMemo(() => {
        const data = filteredTransactions.filter(t => t.type === chartType);
        const grouped = data.reduce((acc, t) => {
            if (!acc[t.category]) {
                acc[t.category] = 0;
            }
            acc[t.category] += t.amount;
            return acc;
        }, {} as Record<string, number>);
        return Object.entries(grouped).map(([name, value]) => ({ name, value }));
    }, [filteredTransactions, chartType]);

    const PIE_COLORS = ['#3b82f6', '#ef4444', '#f97316', '#8b5cf6', '#14b8a6', '#facc15'];
    
    const formatCurrency = (value: number) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(value);

    const handleExport = () => {
        const headers = "ID,Tanggal,Tipe,Kategori,Jumlah,Akun,Catatan,Dibuat Oleh\n";
        const csvContent = filteredTransactions.map(t => 
            `${t.id},${t.date},${t.type},"${t.category}","${t.amount}","${accountMap.get(t.accountId)?.name || 'N/A'}","${t.note}","${t.createdBy}"`
        ).join("\n");

        const blob = new Blob([headers + csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement("a");
        if (link.download !== undefined) {
            const url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", `laporan-keuangan-${filter}-${new Date().toISOString().split('T')[0]}.csv`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    };


    return (
        <div className="space-y-8">
             <div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">Kartu Saya</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                     {accounts.map(account => (
                        <BalanceCard 
                            key={account.id}
                            account={account}
                            balance={formatCurrency(balancesByAccount[account.id] || 0)} 
                            onDelete={onDeleteAccount}
                        />
                     ))}
                    <button 
                        onClick={() => setIsAddAccountModalOpen(true)}
                        className="h-56 flex flex-col items-center justify-center bg-slate-50 border-2 border-dashed border-slate-300 rounded-2xl text-slate-500 hover:bg-slate-100 hover:border-blue-500 hover:text-blue-600 transition-colors"
                    >
                        <PlusIcon className="w-8 h-8" />
                        <span className="mt-2 font-semibold">Tambah Kartu</span>
                    </button>
                </div>
            </div>

            <div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">Ringkasan Periode</h3>
                 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    <StatCard title="Pendapatan dari Klien" value={formatCurrency(summary.incomeFromClients)} icon={<PlusCircleIcon className="w-6 h-6 text-green-600" />} />
                    <StatCard title="Pembayaran ke Barber" value={formatCurrency(summary.barberPayments)} icon={<UsersIcon className="w-6 h-6 text-purple-600" />} />
                    <StatCard title="Total Pengeluaran" value={formatCurrency(summary.totalExpenses)} icon={<MinusCircleIcon className="w-6 h-6 text-red-600" />} />
                    <StatCard title="Laba Bersih" value={formatCurrency(summary.net)} icon={<DollarSignIcon className="w-6 h-6" />} />
                </div>
            </div>
            
            <div className="bg-slate-100 p-4 rounded-xl border">
                <h3 className="text-xl font-bold text-gray-800 mb-4 px-2">Analisis & Laporan</h3>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                         <h3 className="text-lg font-bold text-gray-800 mb-4">Tren Pemasukan vs Pengeluaran</h3>
                         <div style={{ width: '100%', height: 300 }}>
                            <ResponsiveContainer>
                                <LineChart data={chartData}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="date" tickFormatter={(tick) => new Date(tick).toLocaleDateString('id-ID', {day: '2-digit', month: 'short'})} />
                                    <YAxis tickFormatter={(tick) => `${(tick/1000)}k`}/>
                                    <Tooltip contentStyle={{ borderRadius: '0.75rem' }} formatter={(value: number) => formatCurrency(value)} />
                                    <Legend />
                                    <Line type="monotone" dataKey="income" name="Pemasukan" stroke="#3b82f6" strokeWidth={2} />
                                    <Line type="monotone" dataKey="expense" name="Pengeluaran" stroke="#ef4444" strokeWidth={2} />
                                </LineChart>
                            </ResponsiveContainer>
                         </div>
                    </div>
                     <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                        <div className="flex justify-between items-center mb-4">
                             <h3 className="text-lg font-bold text-gray-800">Rincian Kategori</h3>
                             <div className="flex items-center bg-slate-100 p-1 rounded-lg">
                                <button onClick={() => setChartType('income')} className={`px-2 py-1 text-xs font-semibold rounded-md ${chartType === 'income' ? 'bg-white shadow-sm text-blue-600': 'text-gray-500'}`}>Pemasukan</button>
                                <button onClick={() => setChartType('expense')} className={`px-2 py-1 text-xs font-semibold rounded-md ${chartType === 'expense' ? 'bg-white shadow-sm text-red-600': 'text-gray-500'}`}>Pengeluaran</button>
                             </div>
                        </div>
                         <div style={{ width: '100%', height: 300 }}>
                            <ResponsiveContainer>
                                <PieChart>
                                    <Pie data={pieChartData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} fill="#8884d8" label>
                                         {pieChartData.map((entry, index) => <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />)}
                                    </Pie>
                                    <Tooltip formatter={(value: number) => formatCurrency(value)} />
                                    <Legend />
                                </PieChart>
                            </ResponsiveContainer>
                         </div>
                    </div>
                </div>
            </div>


            <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex flex-col md:flex-row justify-between items-center gap-4">
                <div className="flex flex-wrap items-center gap-2">
                    <div className="flex items-center bg-slate-100 p-1 rounded-lg">
                        {(['today', 'week', 'month'] as FilterPeriod[]).map(period => (
                            <button key={period} onClick={() => setFilter(period)} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors ${filter === period ? 'bg-white shadow-sm text-blue-600' : 'text-gray-500 hover:text-gray-800'}`}>
                                {period === 'today' ? 'Hari Ini' : period === 'week' ? 'Minggu Ini' : 'Bulan Ini'}
                            </button>
                        ))}
                    </div>
                    <div className="relative flex items-center">
                        <FilterIcon className="w-5 h-5 absolute left-3 text-gray-400 pointer-events-none" />
                        <select 
                            value={selectedCategory}
                            onChange={e => setSelectedCategory(e.target.value)}
                            className="pl-10 pr-4 py-2 text-sm font-semibold text-gray-600 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors appearance-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 w-full md:w-auto"
                        >
                            {allCategories.map(cat => (
                                <option key={cat} value={cat}>{cat === 'all' ? 'Semua Kategori' : cat}</option>
                            ))}
                        </select>
                    </div>
                </div>
                 <div className="flex items-center space-x-2">
                    <button onClick={handleExport} className="flex items-center space-x-2 px-4 py-2 text-sm font-semibold text-gray-600 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors">
                        <DownloadIcon className="w-4 h-4" />
                        <span>Export CSV</span>
                    </button>
                    <button onClick={() => setIsModalOpen(true)} className="flex items-center space-x-2 px-4 py-2 text-sm font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors">
                        <PlusIcon className="w-4 h-4" />
                        <span>Tambah Transaksi</span>
                    </button>
                </div>
            </div>
            
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-slate-50">
                            <tr>
                                <th scope="col" className="px-6 py-3">Tanggal</th>
                                <th scope="col" className="px-6 py-3">Kategori</th>
                                <th scope="col" className="px-6 py-3">Akun</th>
                                <th scope="col" className="px-6 py-3">Catatan</th>
                                <th scope="col" className="px-6 py-3 text-right">Jumlah</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredTransactions.map(t => {
                                const account = accountMap.get(t.accountId);
                                const accountType = account?.type || 'Tunai';
                                const accountName = account?.name || 'N/A';
                                
                                return (
                                <tr key={t.id} className="bg-white border-b">
                                    <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">{new Date(t.date).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</td>
                                    <td className="px-6 py-4">
                                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${t.type === 'income' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                            {t.category}
                                        </span>
                                    </td>
                                     <td className="px-6 py-4">
                                        <span className={`inline-flex items-center gap-1.5 px-2 py-1 text-xs font-medium rounded-full ${accountType === 'Bank' ? 'bg-indigo-100 text-indigo-800' : 'bg-emerald-100 text-emerald-800'}`}>
                                            {accountType === 'Bank' ? <CreditCardIcon className="w-3 h-3" /> : <WalletIcon className="w-3 h-3" />}
                                            {accountName}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4">{t.note}</td>
                                    <td className={`px-6 py-4 text-right font-semibold ${t.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                                        {t.type === 'income' ? '+' : '-'} {formatCurrency(t.amount)}
                                    </td>
                                </tr>
                            )})}
                        </tbody>
                    </table>
                </div>
                {filteredTransactions.length === 0 && (
                    <p className="text-center text-gray-500 py-12">Tidak ada transaksi pada periode ini.</p>
                )}
            </div>
             {isModalOpen && <AddTransactionModal onClose={() => setIsModalOpen(false)} onSave={onAddTransaction} categories={categories} accounts={accounts}/>}
             {isAddAccountModalOpen && <AddAccountModal onClose={() => setIsAddAccountModalOpen(false)} onSave={onAddAccount} />}
        </div>
    );
};

export default Finance;