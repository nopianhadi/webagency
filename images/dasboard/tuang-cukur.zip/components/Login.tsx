import React, { useState } from 'react';
import { Employee } from '../types';
import { ScissorsIcon } from './icons/ScissorsIcon';

interface LoginProps {
    employees: Employee[];
    onLogin: (employee: Employee) => void;
}

const Login: React.FC<LoginProps> = ({ employees, onLogin }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleLoginSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        const user = employees.find(emp => emp.username === username && emp.password === password);
        if (user) {
            onLogin(user);
        } else {
            setError('Username atau sandi salah.');
        }
    };

    return (
        <div className="min-h-screen bg-slate-100 flex flex-col items-center justify-center p-4">
             <div className="text-center mb-10">
                <div className="flex items-center justify-center space-x-3">
                    <div className="bg-blue-600 p-3 rounded-xl">
                    <ScissorsIcon className="w-8 h-8 text-white" />
                    </div>
                    <h1 className="text-4xl font-bold text-gray-800 tracking-wider">
                    Tuang <span className="text-blue-600">Cukur</span>
                    </h1>
                </div>
                <p className="mt-2 text-lg text-gray-500">Sistem Manajemen Barbershop</p>
            </div>

            <div className="w-full max-w-sm bg-white p-8 rounded-2xl shadow-lg border border-slate-200">
                <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">Login</h2>
                <form onSubmit={handleLoginSubmit} className="space-y-4">
                    <div>
                        <label className="text-sm font-medium text-gray-600">Username</label>
                        <input 
                            type="text" 
                            value={username} 
                            onChange={e => setUsername(e.target.value)} 
                            placeholder="Masukkan username" 
                            className="w-full mt-1 p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                            required 
                        />
                    </div>
                    <div>
                        <label className="text-sm font-medium text-gray-600">Sandi</label>
                        <input 
                            type="password" 
                            value={password} 
                            onChange={e => setPassword(e.target.value)} 
                            placeholder="Masukkan sandi" 
                            className="w-full mt-1 p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                            required 
                        />
                    </div>
                    {error && <p className="text-sm text-red-500 text-center">{error}</p>}
                    <button type="submit" className="w-full mt-4 px-4 py-3 text-sm font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors">
                        Login
                    </button>
                </form>
                 <div className="mt-6 p-4 bg-slate-50 border border-slate-200 rounded-lg text-xs text-gray-500">
                    <p className="font-bold text-gray-600 mb-2 text-center">Gunakan akun demo:</p>
                    <div className="space-y-2">
                        <div>
                            <p className="font-semibold text-gray-700">Admin:</p>
                            <p>Username: <strong className="text-gray-800">admin</strong> | Sandi: <strong className="text-gray-800">password</strong></p>
                        </div>
                        <div>
                            <p className="font-semibold text-gray-700">Kasir (Cashier):</p>
                            <p>Username: <strong className="text-gray-800">citra</strong> | Sandi: <strong className="text-gray-800">password123</strong></p>
                        </div>
                        <div>
                            <p className="font-semibold text-gray-700">Barber:</p>
                            <p>Username: <strong className="text-gray-800">budi</strong> | Sandi: <strong className="text-gray-800">password123</strong></p>
                        </div>
                    </div>
                </div>
            </div>
             <footer className="mt-8 text-sm text-gray-500">
                © {new Date().getFullYear()} Tuang Cukur. All rights reserved.
            </footer>
        </div>
    );
};

export default Login;