import React, { useState, useMemo } from 'react';
import { Transaction, Employee, Service, Payroll, Account, TransactionType } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import StatCard from './StatCard';
import { DollarSignIcon } from './icons/DollarSignIcon';
import { DownloadIcon } from './icons/DownloadIcon';
import { ChartBarIcon } from './icons/ChartBarIcon';
import { BriefcaseIcon } from './icons/BriefcaseIcon';
import { TagIcon } from './icons/TagIcon';
import { UsersIcon } from './icons/UsersIcon';
import { TrendingUpIcon } from './icons/TrendingUpIcon';

interface ReportsProps {
  transactions: Transaction[];
  employees: Employee[];
  services: Service[];
  payrolls: Payroll[];
  accounts: Account[];
}

type FilterPeriod = 'today' | 'week' | 'month' | 'custom';
type ActiveTab = 'finance' | 'barber' | 'service';

const formatCurrency = (value: number) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(value);

const Reports: React.FC<ReportsProps> = ({ transactions, employees, services, payrolls, accounts }) => {
    const [activeTab, setActiveTab] = useState<ActiveTab>('finance');
    const [period, setPeriod] = useState<FilterPeriod>('month');
    const [startDate, setStartDate] = useState(new Date(new Date().setDate(1)).toISOString().split('T')[0]);
    const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
    const [selectedBarberId, setSelectedBarberId] = useState<number | 'all'>('all');

    const handlePeriodChange = (newPeriod: FilterPeriod) => {
        setPeriod(newPeriod);
        const now = new Date();
        if (newPeriod === 'today') {
            setStartDate(now.toISOString().split('T')[0]);
            setEndDate(now.toISOString().split('T')[0]);
        } else if (newPeriod === 'week') {
            const firstDayOfWeek = new Date(now.setDate(now.getDate() - now.getDay()));
            setStartDate(firstDayOfWeek.toISOString().split('T')[0]);
            setEndDate(new Date().toISOString().split('T')[0]);
        } else if (newPeriod === 'month') {
            const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
            setStartDate(firstDayOfMonth.toISOString().split('T')[0]);
            setEndDate(new Date().toISOString().split('T')[0]);
        }
    };
    
    const filteredTransactions = useMemo(() => {
        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0);
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);

        return transactions.filter(t => {
            const tDate = new Date(t.date);
            return tDate >= start && tDate <= end;
        });
    }, [transactions, startDate, endDate]);

    // --- Finance Tab Data ---
    const financeSummary = useMemo(() => {
        const totalIncome = filteredTransactions.filter(t => t.type === TransactionType.INCOME).reduce((sum, t) => sum + t.amount, 0);
        const totalExpense = filteredTransactions.filter(t => t.type === TransactionType.EXPENSE).reduce((sum, t) => sum + t.amount, 0);
        const netProfit = totalIncome - totalExpense;
        return { totalIncome, totalExpense, netProfit };
    }, [filteredTransactions]);

    const financeTrendData = useMemo(() => {
        const grouped = filteredTransactions.reduce((acc, t) => {
            const date = t.date;
            if (!acc[date]) acc[date] = { date, Pendapatan: 0, Pengeluaran: 0 };
            if (t.type === TransactionType.INCOME) acc[date].Pendapatan += t.amount;
            else acc[date].Pengeluaran += t.amount;
            return acc;
        }, {} as Record<string, any>);
        // FIX: Explicitly typed sort callback parameters to fix 'unknown' type error.
        return Object.values(grouped).sort((a: { date: string }, b: { date: string }) => new Date(a.date).getTime() - new Date(b.date).getTime());
    }, [filteredTransactions]);

    const incomePieData = useMemo(() => {
        const grouped = filteredTransactions.filter(t => t.type === TransactionType.INCOME).reduce((acc, t) => {
            if (!acc[t.category]) acc[t.category] = 0;
            acc[t.category] += t.amount;
            return acc;
        }, {} as Record<string, number>);
        return Object.entries(grouped).map(([name, value]) => ({ name, value }));
    }, [filteredTransactions]);

    const expensePieData = useMemo(() => {
        const grouped = filteredTransactions.filter(t => t.type === TransactionType.EXPENSE).reduce((acc, t) => {
            if (!acc[t.category]) acc[t.category] = 0;
            acc[t.category] += t.amount;
            return acc;
        }, {} as Record<string, number>);
        return Object.entries(grouped).map(([name, value]) => ({ name, value }));
    }, [filteredTransactions]);

    // --- Barber Performance Data ---
    const barberPerformance = useMemo(() => {
        const barbers = employees.filter(e => e.role === 'Barber');
        return barbers.map(barber => {
            const barberTransactions = filteredTransactions.filter(t => t.note.includes(`(oleh ${barber.name})`));
            const revenueGenerated = barberTransactions.reduce((sum, t) => sum + t.amount, 0);
            const customersServed = barberTransactions.length;
            const commissionEarned = revenueGenerated * (barber.commission / 100);
            return {
                id: barber.id,
                name: barber.name,
                avatarUrl: barber.avatarUrl,
                revenueGenerated,
                customersServed,
                commissionEarned
            };
        }).sort((a,b) => b.revenueGenerated - a.revenueGenerated);
    }, [filteredTransactions, employees]);

    // --- Service Analysis Data ---
    const serviceAnalysis = useMemo(() => {
        return services.map(service => {
            const serviceTransactions = filteredTransactions.filter(t => t.category === service.name);
            const timesSold = serviceTransactions.length;
            const totalRevenue = serviceTransactions.reduce((sum, t) => sum + t.amount, 0);
            return { ...service, timesSold, totalRevenue };
        }).sort((a,b) => b.timesSold - a.timesSold);
    }, [filteredTransactions, services]);
    
    const handleExport = (data: any[], filename: string) => {
        if (data.length === 0) return;
        const headers = Object.keys(data[0]).join(',');
        const csv = data.map(row => Object.values(row).join(',')).join('\n');
        const blob = new Blob([headers + '\n' + csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.setAttribute('hidden', '');
        a.setAttribute('href', url);
        a.setAttribute('download', `${filename}.csv`);
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    };


    const renderContent = () => {
        switch (activeTab) {
            case 'finance':
                return (
                    <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <StatCard title="Total Pendapatan" value={formatCurrency(financeSummary.totalIncome)} icon={<UsersIcon className="w-6 h-6 text-green-500" />} />
                            <StatCard title="Total Pengeluaran" value={formatCurrency(financeSummary.totalExpense)} icon={<TrendingUpIcon className="w-6 h-6 text-red-500 rotate-180" />} />
                            <StatCard title="Laba Bersih" value={formatCurrency(financeSummary.netProfit)} icon={<DollarSignIcon className="w-6 h-6 text-blue-500" />} />
                        </div>
                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                             <div className="flex justify-between items-center mb-4">
                                <h3 className="text-lg font-bold text-gray-800">Tren Keuangan</h3>
                                <button onClick={() => handleExport(financeTrendData, 'tren_keuangan')} className="flex items-center space-x-2 px-3 py-1.5 text-xs font-semibold text-gray-600 bg-slate-100 rounded-lg hover:bg-slate-200">
                                    <DownloadIcon className="w-4 h-4" />
                                    <span>Export CSV</span>
                                </button>
                            </div>
                            <div style={{ width: '100%', height: 300 }}>
                                <ResponsiveContainer>
                                    <LineChart data={financeTrendData}>
                                        <CartesianGrid strokeDasharray="3 3" />
                                        <XAxis dataKey="date" tickFormatter={(tick) => new Date(tick).toLocaleDateString('id-ID', { day: '2-digit', month: 'short' })} />
                                        <YAxis tickFormatter={(tick) => `${(tick/1000)}k`}/>
                                        <Tooltip formatter={(value: number) => formatCurrency(value)} />
                                        <Legend />
                                        <Line type="monotone" dataKey="Pendapatan" stroke="#10b981" />
                                        <Line type="monotone" dataKey="Pengeluaran" stroke="#ef4444" />
                                    </LineChart>
                                </ResponsiveContainer>
                            </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                           <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                                <h3 className="text-lg font-bold text-gray-800 mb-4">Komposisi Pendapatan</h3>
                                <ResponsiveContainer width="100%" height={250}>
                                    <PieChart>
                                        <Pie data={incomePieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} fill="#82ca9d" label />
                                        <Tooltip formatter={(value: number) => formatCurrency(value)} />
                                    </PieChart>
                                </ResponsiveContainer>
                           </div>
                           <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                                <h3 className="text-lg font-bold text-gray-800 mb-4">Komposisi Pengeluaran</h3>
                                <ResponsiveContainer width="100%" height={250}>
                                    <PieChart>
                                        <Pie data={expensePieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} fill="#ef4444" label />
                                        <Tooltip formatter={(value: number) => formatCurrency(value)} />
                                    </PieChart>
                                </ResponsiveContainer>
                           </div>
                        </div>
                    </div>
                );
            case 'barber':
                return (
                     <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                         <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-bold text-gray-800">Papan Peringkat Kinerja Barber</h3>
                            <button onClick={() => handleExport(barberPerformance, 'kinerja_barber')} className="flex items-center space-x-2 px-3 py-1.5 text-xs font-semibold text-gray-600 bg-slate-100 rounded-lg hover:bg-slate-200">
                                <DownloadIcon className="w-4 h-4" />
                                <span>Export CSV</span>
                            </button>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                                <thead className="text-xs text-gray-700 uppercase bg-slate-50">
                                    <tr>
                                        <th className="px-4 py-3">Peringkat</th>
                                        <th className="px-4 py-3">Barber</th>
                                        <th className="px-4 py-3 text-right">Pendapatan</th>
                                        <th className="px-4 py-3 text-right">Pelanggan</th>
                                        <th className="px-4 py-3 text-right">Komisi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {barberPerformance.map((barber, index) => (
                                        <tr key={barber.id} className="border-b">
                                            <td className="px-4 py-3 font-bold text-center">{index + 1}</td>
                                            <td className="px-4 py-3">
                                                <div className="flex items-center space-x-3">
                                                    <img src={barber.avatarUrl} className="w-8 h-8 rounded-full" />
                                                    <span>{barber.name}</span>
                                                </div>
                                            </td>
                                            <td className="px-4 py-3 text-right font-semibold">{formatCurrency(barber.revenueGenerated)}</td>
                                            <td className="px-4 py-3 text-right font-semibold">{barber.customersServed}</td>
                                            <td className="px-4 py-3 text-right font-semibold text-green-600">{formatCurrency(barber.commissionEarned)}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                );
            case 'service':
                return (
                    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-bold text-gray-800">Analisis Popularitas Layanan</h3>
                             <button onClick={() => handleExport(serviceAnalysis, 'analisis_layanan')} className="flex items-center space-x-2 px-3 py-1.5 text-xs font-semibold text-gray-600 bg-slate-100 rounded-lg hover:bg-slate-200">
                                <DownloadIcon className="w-4 h-4" />
                                <span>Export CSV</span>
                            </button>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                                <thead className="text-xs text-gray-700 uppercase bg-slate-50">
                                    <tr>
                                        <th className="px-4 py-3">Layanan</th>
                                        <th className="px-4 py-3 text-right">Terjual</th>
                                        <th className="px-4 py-3 text-right">Total Pendapatan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {serviceAnalysis.map(service => (
                                        <tr key={service.id} className="border-b">
                                            <td className="px-4 py-3 font-semibold">{service.name}</td>
                                            <td className="px-4 py-3 text-right font-semibold">{service.timesSold} kali</td>
                                            <td className="px-4 py-3 text-right font-semibold text-blue-600">{formatCurrency(service.totalRevenue)}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                );
            default:
                return null;
        }
    };

    return (
        <div className="space-y-6">
            <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center bg-slate-100 p-1 rounded-lg">
                    {(['today', 'week', 'month'] as FilterPeriod[]).map(p => (
                        <button key={p} onClick={() => handlePeriodChange(p)} className={`px-4 py-2 text-sm font-semibold rounded-md ${period === p ? 'bg-white shadow text-blue-600' : 'text-gray-500'}`}>
                            {p === 'today' ? 'Hari Ini' : p === 'week' ? 'Minggu Ini' : 'Bulan Ini'}
                        </button>
                    ))}
                    <button onClick={() => setPeriod('custom')} className={`px-4 py-2 text-sm font-semibold rounded-md ${period === 'custom' ? 'bg-white shadow text-blue-600' : 'text-gray-500'}`}>
                        Kustom
                    </button>
                </div>
                {period === 'custom' && (
                    <div className="flex items-center gap-2">
                        <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="p-2 border rounded-lg text-sm" />
                        <span>-</span>
                        <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="p-2 border rounded-lg text-sm" />
                    </div>
                )}
            </div>

            <div className="border-b border-slate-200">
                <nav className="flex -mb-px space-x-8">
                    <button onClick={() => setActiveTab('finance')} className={`flex items-center px-1 py-4 border-b-2 text-sm font-medium ${activeTab === 'finance' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
                        <ChartBarIcon className="w-5 h-5 mr-2" /> Laporan Keuangan
                    </button>
                    <button onClick={() => setActiveTab('barber')} className={`flex items-center px-1 py-4 border-b-2 text-sm font-medium ${activeTab === 'barber' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
                        <BriefcaseIcon className="w-5 h-5 mr-2" /> Kinerja Barber
                    </button>
                     <button onClick={() => setActiveTab('service')} className={`flex items-center px-1 py-4 border-b-2 text-sm font-medium ${activeTab === 'service' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
                        <TagIcon className="w-5 h-5 mr-2" /> Analisis Layanan
                    </button>
                </nav>
            </div>
            
            <div>
                {renderContent()}
            </div>
        </div>
    );
};

export default Reports;