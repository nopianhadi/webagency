import React, { useState, useCallback } from 'react';
import { Page, QueueItem, QueueStatus, Transaction, Employee, Attendance, EmployeeStatus, AttendanceStatus, TransactionType, Service, Account, Payroll } from './types';
import Dashboard from './components/Dashboard';
import QueuePortal from './components/QueuePortal';
import PublicQueue from './components/PublicQueue';
import Finance from './components/Finance';
import Header from './components/Header';
import BarberManagement from './components/BarberManagement';
import Settings from './components/Settings';
import Login from './components/Login';
import Reports from './components/Reports';
import { mockEmployees, mockQueue, mockTransactions, mockAttendance, initialCategories, mockServices, mockAccounts } from './constants';


const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [currentUser, setCurrentUser] = useState<Employee | null>(null);
  const [employees, setEmployees] = useState<Employee[]>(mockEmployees);
  const [queue, setQueue] = useState<QueueItem[]>(mockQueue);
  const [transactions, setTransactions] = useState<Transaction[]>(mockTransactions);
  const [attendance, setAttendance] = useState<Attendance[]>(mockAttendance);
  const [transactionCategories, setTransactionCategories] = useState(initialCategories);
  const [employeeStatuses, setEmployeeStatuses] = useState<string[]>(Object.values(EmployeeStatus));
  const [services, setServices] = useState<Service[]>(mockServices);
  const [accounts, setAccounts] = useState<Account[]>(mockAccounts);
  const [payrolls, setPayrolls] = useState<Payroll[]>([]);

  const handleLogin = (user: Employee) => {
    setCurrentUser(user);
    setCurrentPage('dashboard');
  };

  const handleLogout = () => {
    setCurrentUser(null);
  };

  const handleStartService = useCallback((id: number) => {
    setQueue(prevQueue => {
      return prevQueue.map(item =>
        item.id === id ? { ...item, status: QueueStatus.SERVING } : item
      );
    });
  }, []);
  
  const handleAddTransaction = useCallback((transaction: Omit<Transaction, 'id'>) => {
    setTransactions(prev => [...prev, { ...transaction, id: Date.now() }]);
  }, []);

  const handleFinishService = useCallback((item: QueueItem) => {
    setQueue(prevQueue => 
      prevQueue.map(i =>
        i.id === item.id ? { ...i, status: QueueStatus.DONE } : i
      )
    );

    if (!transactionCategories.income.includes(item.service.name)) {
        setTransactionCategories(prev => ({
            ...prev,
            income: [...prev.income, item.service.name]
        }));
    }
    
    const cashAccount = accounts.find(acc => acc.type === 'Tunai');
    if (!cashAccount) {
        alert("Tidak ada akun kas tunai yang ditemukan. Silakan buat akun di menu Keuangan.");
        return;
    }

    const newTransaction: Omit<Transaction, 'id'> = {
      date: new Date().toISOString().split('T')[0],
      type: TransactionType.INCOME,
      category: item.service.name,
      amount: item.service.price,
      note: `Pelanggan: ${item.customerName} (oleh ${item.barber.name})`,
      createdBy: currentUser?.name || 'System',
      accountId: cashAccount.id,
      commissionPaid: false, // Mark commission as unpaid initially
    };
    handleAddTransaction(newTransaction);
  }, [transactionCategories, handleAddTransaction, currentUser, accounts]);

  const handleSkipCustomer = useCallback((id: number) => {
     setQueue(prevQueue => prevQueue.filter(item => item.id !== id));
  }, []);

  interface AddToQueueData {
    customerName: string;
    serviceId: number;
    barberId: number;
  }
  const handleAddToQueue = useCallback((data: AddToQueueData) => {
      const service = services.find(s => s.id === data.serviceId);
      const barber = employees.find(e => e.id === data.barberId);

      if (!service || !barber) {
          console.error("Service or Barber not found");
          return;
      }
      
      const today = new Date().toISOString().split('T')[0];
      const todaysQueue = queue.filter(q => q.date === today);

      const lastQueueNumber = todaysQueue.length > 0 
        ? Math.max(0, ...todaysQueue.map(q => parseInt(q.queueNumber.split('-')[1]))) 
        : 44;
      const nextQueueNumber = lastQueueNumber + 1;

      const newQueueItem: QueueItem = {
          id: Date.now(),
          customerName: data.customerName,
          service: service,
          barber: barber,
          queueNumber: `TC-${String(nextQueueNumber).padStart(3, '0')}`,
          status: QueueStatus.WAITING,
          createdAt: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
          date: today,
      };

      setQueue(prev => [...prev, newQueueItem]);
  }, [queue, services, employees]);

  const handleUpdateBarberStatus = useCallback((employeeId: number, status: string) => {
    setEmployees(prev => prev.map(emp => emp.id === employeeId ? { ...emp, status } : emp));
  }, []);
  
  const handleAddEmployee = useCallback((employee: Omit<Employee, 'id' | 'status'>) => {
      const newEmployee: Employee = {
          ...employee,
          id: Date.now(),
          status: EmployeeStatus.AVAILABLE,
      };
      setEmployees(prev => [...prev, newEmployee]);
  }, []);

  const handleDeleteEmployee = useCallback((employeeId: number) => {
    if (currentUser?.id === employeeId) {
        alert("Anda tidak dapat menghapus akun Anda sendiri.");
        return;
    }
    if (window.confirm("Apakah Anda yakin ingin menghapus pengguna ini? Tindakan ini tidak dapat diurungkan.")) {
        setEmployees(prev => prev.filter(emp => emp.id !== employeeId));
    }
  }, [currentUser]);

  const handleMarkAttendance = useCallback((employeeId: number, status: AttendanceStatus) => {
    const today = new Date().toISOString().split('T')[0];
    setAttendance(prev => {
        const existingRecord = prev.find(att => att.employeeId === employeeId && att.date === today);
        if (existingRecord) {
            return prev.map(att => att.id === existingRecord.id ? { ...att, status } : att);
        }
        const newRecord: Attendance = { id: Date.now(), employeeId, date: today, status };
        return [...prev, newRecord];
    });
  }, []);

  const handleAddCategory = useCallback((type: TransactionType, category: string) => {
      if (category.trim() === '' || transactionCategories[type].includes(category.trim())) return;
      setTransactionCategories(prev => ({
          ...prev,
          [type]: [...prev[type], category.trim()]
      }));
  }, [transactionCategories]);

  const handleDeleteCategory = useCallback((type: TransactionType, category: string) => {
      setTransactionCategories(prev => ({
          ...prev,
          [type]: prev[type].filter(c => c !== category)
      }));
  }, []);
  
  const handleAddEmployeeStatus = useCallback((status: string) => {
    if (status.trim() === '' || employeeStatuses.includes(status.trim())) return;
    setEmployeeStatuses(prev => [...prev, status.trim()]);
  }, [employeeStatuses]);

  const handleDeleteEmployeeStatus = useCallback((status: string) => {
    setEmployeeStatuses(prev => prev.filter(s => s !== status));
  }, []);

  const handleAddService = useCallback((name: string, price: number) => {
      if (name.trim() === '' || isNaN(price) || price <= 0) return;
      const newService: Service = {
          id: Date.now(),
          name: name.trim(),
          price,
      };
      setServices(prev => [...prev, newService]);
  }, []);

  const handleDeleteService = useCallback((id: number) => {
      setServices(prev => prev.filter(s => s.id !== id));
  }, []);
  
  const handleAddAccount = useCallback((data: Omit<Account, 'id'> & { initialBalance: number }) => {
    const { initialBalance, ...accountDetails } = data;
    
    const newAccount: Account = {
        id: Date.now(),
        ...accountDetails
    };
    setAccounts(prev => [...prev, newAccount]);

    if (initialBalance > 0) {
        const initialTransaction: Omit<Transaction, 'id'> = {
            date: new Date().toISOString().split('T')[0],
            type: TransactionType.INCOME,
            category: 'Saldo Awal',
            amount: initialBalance,
            note: `Saldo awal untuk ${data.name}`,
            createdBy: currentUser?.name || 'System',
            accountId: newAccount.id,
        };
        handleAddTransaction(initialTransaction);
    }
  }, [currentUser, handleAddTransaction]);

  const handleDeleteAccount = useCallback((accountId: number) => {
    const hasTransactions = transactions.some(t => t.accountId === accountId);
    const hasPayrolls = payrolls.some(p => p.accountId === accountId);

    if (hasTransactions || hasPayrolls) {
      alert("Tidak dapat menghapus akun yang memiliki riwayat transaksi atau pembayaran gaji.");
      return;
    }

    if (window.confirm("Apakah Anda yakin ingin menghapus akun ini? Tindakan ini tidak dapat diurungkan.")) {
      setAccounts(prev => prev.filter(acc => acc.id !== accountId));
    }
  }, [transactions, payrolls]);

  const handleProcessPayment = useCallback((employeeId: number, deductions: number, accountId: number, signatureDataUrl: string) => {
    const employee = employees.find(e => e.id === employeeId);
    if (!employee || !currentUser) return;

    const unpaidTransactions = transactions.filter(t => 
        t.type === TransactionType.INCOME && 
        t.note.includes(`(oleh ${employee.name})`) &&
        !t.commissionPaid
    );

    const totalCommission = unpaidTransactions.reduce((sum, t) => {
        return sum + (t.amount * (employee.commission / 100));
    }, 0);

    const baseSalary = (employee.paymentType === 'Gaji Tetap' || employee.paymentType === 'Gaji & Komisi') ? employee.salary : 0;
    const netPay = baseSalary + totalCommission - deductions;

    const newPayroll: Payroll = {
        id: Date.now(),
        employeeId,
        paymentDate: new Date().toISOString().split('T')[0],
        baseSalary,
        totalCommission,
        deductions,
        netPay,
        paidTransactionIds: unpaidTransactions.map(t => t.id),
        accountId,
        processedBy: currentUser.name,
        signatureDataUrl,
    };

    setPayrolls(prev => [...prev, newPayroll]);

    setTransactions(prev => 
        prev.map(t => 
            unpaidTransactions.some(ut => ut.id === t.id) 
            ? { ...t, commissionPaid: true } 
            : t
        )
    );
    
    const expenseAccount = accounts.find(acc => acc.id === accountId);
    if(expenseAccount) {
        const payrollExpense: Omit<Transaction, 'id'> = {
            date: new Date().toISOString().split('T')[0],
            type: TransactionType.EXPENSE,
            category: 'Gaji',
            amount: netPay,
            note: `Pembayaran gaji untuk ${employee.name}`,
            createdBy: currentUser.name,
            accountId: expenseAccount.id,
        };
        handleAddTransaction(payrollExpense);
    }

    alert(`Pembayaran untuk ${employee.name} berhasil diproses!`);
    return newPayroll;
  }, [employees, transactions, currentUser, accounts, handleAddTransaction]);


  const renderPage = () => {
    if (!currentUser) return null;
    
    const defaultPage = <Dashboard 
        employees={employees}
        currentUser={currentUser}
        transactions={transactions}
        queue={queue}
        payrolls={payrolls}
        accounts={accounts}
    />;

    const isAdmin = currentUser.role === 'Admin';
    const isCashier = currentUser.role === 'Cashier';

    switch (currentPage) {
      case 'dashboard':
        return defaultPage;
      case 'queue':
        return (
          <QueuePortal 
            queue={queue}
            employees={employees}
            services={services}
            currentUser={currentUser}
            onStartService={handleStartService}
            onFinishService={handleFinishService}
            onSkipCustomer={handleSkipCustomer}
            onAddToQueue={handleAddToQueue}
          />
        );
      case 'public-queue':
        return <PublicQueue queue={queue} />;
      case 'finance':
        if (!isAdmin && !isCashier) return defaultPage;
        return <Finance 
            transactions={transactions} 
            accounts={accounts}
            payrolls={payrolls}
            onAddTransaction={handleAddTransaction}
            onAddAccount={handleAddAccount}
            onDeleteAccount={handleDeleteAccount}
            categories={transactionCategories} 
        />;
      case 'barbers':
        if (!isAdmin && !isCashier) return defaultPage;
        return (
            <BarberManagement 
                employees={employees}
                attendance={attendance}
                transactions={transactions}
                payrolls={payrolls}
                queue={queue}
                statuses={employeeStatuses}
                accounts={accounts}
                currentUser={currentUser}
                onUpdateStatus={handleUpdateBarberStatus}
                onMarkAttendance={handleMarkAttendance}
                onProcessPayment={handleProcessPayment}
            />
        );
      case 'reports':
        if (!isAdmin && !isCashier) return defaultPage;
        return <Reports 
          transactions={transactions}
          employees={employees}
          services={services}
          payrolls={payrolls}
          accounts={accounts}
        />;
      case 'settings':
        if (!isAdmin) return defaultPage;
        return <Settings 
            categories={transactionCategories}
            onAddCategory={handleAddCategory}
            onDeleteCategory={handleDeleteCategory}
            statuses={employeeStatuses}
            onAddStatus={handleAddEmployeeStatus}
            onDeleteStatus={handleDeleteEmployeeStatus}
            services={services}
            onAddService={handleAddService}
            onDeleteService={handleDeleteService}
            employees={employees}
            onAddEmployee={handleAddEmployee}
            onDeleteEmployee={handleDeleteEmployee}
        />;
      default:
        return defaultPage;
    }
  };

  if (!currentUser) {
    return <Login employees={employees} onLogin={handleLogin} />;
  }

  return (
    <div className={`min-h-screen ${currentPage === 'public-queue' ? 'bg-slate-900' : 'bg-slate-50'} text-gray-800`}>
      {currentPage !== 'public-queue' && <Header currentPage={currentPage} setCurrentPage={setCurrentPage} currentUser={currentUser} onLogout={handleLogout} />}
      <main className={currentPage !== 'public-queue' ? "p-4 sm:p-6 lg:p-8" : ""}>
        {renderPage()}
      </main>
    </div>
  );
};

export default App;