import { Employee, QueueItem, QueueStatus, Transaction, TransactionType, EmployeeStatus, Attendance, AttendanceStatus, Service, Account } from './types';

// --- UTILITY FUNCTIONS ---
const formatDate = (date: Date): string => date.toISOString().split('T')[0];
const getDateDaysAgo = (days: number): Date => {
    const date = new Date();
    date.setDate(date.getDate() - days);
    return date;
};

// --- CORE DATA ---

export const mockServices: Service[] = [
    { id: 1, name: 'Potong Rambut Dewasa', price: 50000 },
    { id: 2, name: 'Hair Spa', price: 150000 },
    { id: 3, name: 'Shave (Kumis & Jenggot)', price: 30000 },
    { id: 4, name: 'Potong Rambut & Shave', price: 75000 },
    { id: 5, name: 'Creambath', price: 100000 },
    { id: 6, name: 'Produk Pomade', price: 120000 },
    { id: 7, name: 'Potong Rambut Anak', price: 35000 },
    { id: 8, name: 'Pewarnaan Rambut', price: 250000 },
    { id: 9, name: 'Black Mask Facial', price: 40000 },
    { id: 10, name: 'Hair Tattoo (Simple)', price: 60000 },
];

export const initialCategories = {
    income: [
        'Saldo Awal', 'Potong Rambut Dewasa', 'Hair Spa', 'Shave (Kumis & Jenggot)', 'Potong Rambut & Shave',
        'Creambath', 'Produk Pomade', 'Potong Rambut Anak', 'Pewarnaan Rambut',
        'Black Mask Facial', 'Hair Tattoo (Simple)', 'Lainnya'
    ],
    expense: ['Gaji', 'Sewa', 'Listrik', 'Air', 'Pembelian Produk', 'Perlengkapan', 'Lainnya'],
};

export const mockEmployees: Employee[] = [
  { id: 1, name: 'Budi', username: 'budi', password: 'password123', role: 'Barber', status: EmployeeStatus.AVAILABLE, avatarUrl: 'https://i.pravatar.cc/150?img=1', salary: 2500000, commission: 15, paymentType: 'Gaji & Komisi' },
  { id: 2, name: 'Andi', username: 'andi', password: 'password123', role: 'Barber', status: EmployeeStatus.AVAILABLE, avatarUrl: 'https://i.pravatar.cc/150?img=2', salary: 0, commission: 30, paymentType: 'Hanya Komisi' },
  { id: 3, name: 'Citra', username: 'citra', password: 'password123', role: 'Cashier', status: EmployeeStatus.AVAILABLE, avatarUrl: 'https://i.pravatar.cc/150?img=3', salary: 3000000, commission: 0, paymentType: 'Gaji Tetap' },
  { id: 4, name: 'Dedi', username: 'dedi', password: 'password123', role: 'Barber', status: EmployeeStatus.ON_BREAK, avatarUrl: 'https://i.pravatar.cc/150?img=4', salary: 2300000, commission: 12, paymentType: 'Gaji & Komisi' },
  { id: 5, name: 'Ferry', username: 'admin', password: 'password', role: 'Admin', status: EmployeeStatus.AVAILABLE, avatarUrl: 'https://i.pravatar.cc/150?img=5', salary: 5000000, commission: 0, paymentType: 'Gaji Tetap' },
  { id: 6, name: 'Eko', username: 'eko', password: 'password123', role: 'Barber', status: EmployeeStatus.AVAILABLE, avatarUrl: 'https://i.pravatar.cc/150?img=6', salary: 0, commission: 35, paymentType: 'Hanya Komisi' },
  { id: 7, name: 'Gita', username: 'gita', password: 'password123', role: 'Barber', status: EmployeeStatus.DAY_OFF, avatarUrl: 'https://i.pravatar.cc/150?img=7', salary: 0, commission: 28, paymentType: 'Hanya Komisi' },
  { id: 8, name: 'Hari', username: 'hari', password: 'password123', role: 'Barber', status: EmployeeStatus.AVAILABLE, avatarUrl: 'https://i.pravatar.cc/150?img=8', salary: 2200000, commission: 10, paymentType: 'Gaji & Komisi' },
  { id: 9, name: 'Indah', username: 'indah', password: 'password123', role: 'Cashier', status: EmployeeStatus.AVAILABLE, avatarUrl: 'https://i.pravatar.cc/150?img=9', salary: 3200000, commission: 0, paymentType: 'Gaji Tetap' },
  { id: 10, name: 'Joko', username: 'joko', password: 'password123', role: 'Barber', status: EmployeeStatus.SERVING, avatarUrl: 'https://i.pravatar.cc/150?img=10', salary: 0, commission: 32, paymentType: 'Hanya Komisi' },
];

export const mockAccounts: Account[] = [
    { id: 1, name: 'Bank BCA', type: 'Bank', bankName: 'BCA', accountHolder: 'Ferry Admin', last4Digits: '9018' },
    { id: 2, name: 'Kas Toko', type: 'Tunai' },
    { id: 3, name: 'Bank Mandiri', type: 'Bank', bankName: 'Mandiri', accountHolder: 'Ferry Admin', last4Digits: '1121' },
    { id: 4, name: 'Dompet Digital', type: 'Tunai' },
];

// --- GENERATED MOCK DATA (1 MONTH) ---

const barbers = mockEmployees.filter(e => e.role === 'Barber');
const customerNames = ['Rizky', 'Fajar', 'Eka', 'Bambang', 'Susi', 'Tono', 'Dewi', 'Agus', 'Putri', 'Hadi', 'Lina', 'Yoga'];

// Transactions
const generatedTransactions: Transaction[] = [];
for (let i = 29; i >= 0; i--) {
    const date = getDateDaysAgo(i);
    const dailyTransactions = Math.floor(Math.random() * 5) + 2; // 2-6 transactions per day

    for (let j = 0; j < dailyTransactions; j++) {
        const barber = barbers[Math.floor(Math.random() * barbers.length)];
        const service = mockServices[Math.floor(Math.random() * mockServices.length)];
        const customer = customerNames[Math.floor(Math.random() * customerNames.length)];
        const account = mockAccounts[Math.random() > 0.3 ? 1 : 0]; // 70% cash, 30% bank
        
        generatedTransactions.push({
            id: Date.now() + i * 100 + j,
            date: formatDate(date),
            type: TransactionType.INCOME,
            category: service.name,
            amount: service.price,
            note: `Pelanggan: ${customer} (oleh ${barber.name})`,
            createdBy: 'Citra',
            accountId: account.id,
            commissionPaid: i > 15, // Commissions from >15 days ago are paid
        });
    }
    // Add some expenses
    if (i % 5 === 0) { // Every 5 days
        generatedTransactions.push({
            id: Date.now() + i * 100 + 99,
            date: formatDate(date),
            type: TransactionType.EXPENSE,
            category: 'Pembelian Produk',
            amount: Math.floor(Math.random() * 200000) + 150000,
            note: 'Stok pomade & shampoo',
            createdBy: 'Ferry',
            accountId: 1,
        });
    }
}
// Add some big monthly expenses
generatedTransactions.push({ id: 9001, date: formatDate(getDateDaysAgo(28)), type: TransactionType.EXPENSE, category: 'Sewa', amount: 4500000, note: 'Sewa Ruko Bulan Ini', createdBy: 'Ferry', accountId: 1 });
generatedTransactions.push({ id: 9002, date: formatDate(getDateDaysAgo(5)), type: TransactionType.EXPENSE, category: 'Listrik', amount: 750000, note: 'Tagihan Listrik', createdBy: 'Ferry', accountId: 1 });
// Add Initial Balance Transactions
generatedTransactions.unshift(
    { id: 10001, date: formatDate(getDateDaysAgo(29)), type: TransactionType.INCOME, category: 'Saldo Awal', amount: 25000000, note: 'Saldo awal Bank BCA', createdBy: 'System', accountId: 1 },
    { id: 10002, date: formatDate(getDateDaysAgo(29)), type: TransactionType.INCOME, category: 'Saldo Awal', amount: 5000000, note: 'Saldo awal Kas Toko', createdBy: 'System', accountId: 2 },
    { id: 10003, date: formatDate(getDateDaysAgo(20)), type: TransactionType.INCOME, category: 'Saldo Awal', amount: 15000000, note: 'Saldo awal Bank Mandiri', createdBy: 'System', accountId: 3 },
    { id: 10004, date: formatDate(getDateDaysAgo(20)), type: TransactionType.INCOME, category: 'Saldo Awal', amount: 2000000, note: 'Saldo awal Dompet Digital', createdBy: 'System', accountId: 4 }
);

export const mockTransactions: Transaction[] = generatedTransactions;


// Queue
const generatedQueue: QueueItem[] = [];
let queueCounter = 45;
for (let i = 4; i >= 0; i--) {
    const date = getDateDaysAgo(i);
    const dailyCustomers = Math.floor(Math.random() * 6) + 5;
    for (let j = 0; j < dailyCustomers; j++) {
        const barber = barbers[Math.floor(Math.random() * barbers.length)];
        const service = mockServices[Math.floor(Math.random() * mockServices.length-1)]; // Exclude product purchase
        const customer = customerNames[Math.floor(Math.random() * customerNames.length)];
        
        let status = QueueStatus.DONE;
        if (i === 0) { // Today's queue
            if (j === dailyCustomers - 1) status = QueueStatus.SERVING;
            else if (j >= dailyCustomers - 3) status = QueueStatus.WAITING;
        }

        generatedQueue.push({
            id: Date.now() + i * 100 + j,
            customerName: `${customer} ${j+1}`,
            service: service,
            barber: barber,
            queueNumber: `TC-${String(queueCounter++).padStart(3, '0')}`,
            status: status,
            createdAt: `${String(9+j).padStart(2,'0')}:${String(Math.floor(Math.random()*60)).padStart(2,'0')}`,
            date: formatDate(date),
        });
    }
}
export const mockQueue: QueueItem[] = generatedQueue.reverse();


// Attendance
const generatedAttendance: Attendance[] = [];
for (let i = 4; i >= 0; i--) {
    const date = getDateDaysAgo(i);
    mockEmployees.forEach(emp => {
        if (emp.role === 'Barber') {
             generatedAttendance.push({
                id: Date.now() + i * 100 + emp.id,
                employeeId: emp.id,
                date: formatDate(date),
                status: emp.id === 7 ? AttendanceStatus.ABSENT : (Math.random() > 0.1 ? AttendanceStatus.PRESENT : AttendanceStatus.ABSENT), // Gita is mostly absent
            });
        }
    });
}
export const mockAttendance: Attendance[] = generatedAttendance;