

export interface Service {
  id: number;
  name: string;
  price: number;
}

export type PaymentType = 'Gaji Tetap' | 'Hanya Komisi' | 'Gaji & Komisi';

export interface Employee {
  id: number;
  name: string;
  username: string;
  password: string;
  role: 'Barber' | 'Cashier' | 'Admin';
  status: string; // Changed from EmployeeStatus to string for dynamic statuses
  avatarUrl: string;
  salary: number;
  commission: number; // Percentage
  paymentType: PaymentType;
}

export enum EmployeeStatus {
  AVAILABLE = 'Available',
  SERVING = 'Serving',
  ON_BREAK = 'On Break',
  DAY_OFF = 'Day Off',
}

export enum QueueStatus {
  WAITING = 'waiting',
  SERVING = 'serving',
  DONE = 'done',
}

export interface QueueItem {
  id: number;
  customerName: string;
  service: Service;
  barber: Employee;
  queueNumber: string;
  status: QueueStatus;
  createdAt: string;
  date: string; // YYYY-MM-DD format
}

export type Page = 'dashboard' | 'queue' | 'finance' | 'barbers' | 'reports' | 'settings' | 'public-queue';

// New Types for Finance Module
export enum TransactionType {
    INCOME = 'income',
    EXPENSE = 'expense',
}

export const TransactionCategories = {
    income: ['Potong Rambut', 'Hair Spa', 'Produk', 'Lainnya'],
    expense: ['Gaji', 'Sewa', 'Listrik', 'Produk', 'Lainnya'],
};

export interface Account {
  id: number;
  name: string;
  type: 'Bank' | 'Tunai';
  bankName?: string;
  accountHolder?: string;
  last4Digits?: string;
}

export interface Transaction {
    id: number;
    date: string; // YYYY-MM-DD format
    type: TransactionType;
    category: string;
    amount: number;
    note: string;
    createdBy: string;
    accountId: number;
    commissionPaid?: boolean;
}

// New Types for Barber Management
export enum AttendanceStatus {
    PRESENT = 'Present',
    ABSENT = 'Absent',
}

export interface Attendance {
    id: number;
    employeeId: number;
    date: string; // YYYY-MM-DD
    status: AttendanceStatus;
}

export interface Payroll {
  id: number;
  employeeId: number;
  paymentDate: string;
  baseSalary: number;
  totalCommission: number;
  deductions: number;
  netPay: number;
  paidTransactionIds: number[];
  accountId: number;
  processedBy: string;
  signatureDataUrl?: string;
}